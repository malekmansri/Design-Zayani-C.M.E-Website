export type Language = 'fr' | 'en' | 'ar';

export const translations = {
  fr: {
    // Navigation
    nav: {
      home: 'Accueil',
      about: 'À propos',
      machines: 'Machines',
      sectors: 'Secteurs',
      services: 'Services',
      contact: 'Contact'
    },
    // Hero
    hero: {
      badge: 'Fièrement Fabriqué en Tunisie Depuis 2007',
      title: 'Machines de Conditionnement & d\'Étiquetage Industrielles',
      subtitle: 'Solutions manuelles, semi-automatiques et automatiques pour optimiser votre ligne de production',
      cta1: 'Voir les machines',
      cta2: 'Demander un devis',
      stats: {
        years: 'Ans d\'Excellence',
        machines: 'Machines Déployées',
        local: 'Fabrication Locale',
        support: 'Support'
      }
    },
    // About
    about: {
      badge: 'QUI SOMMES-NOUS',
      title: 'Excellence en Ingénierie',
      titleAccent: 'Depuis 2007',
      description: 'Fondée en 2007 à Nabeul, Tunisie, Zayani C.M.E conçoit et fabrique des machines d\'étiquetage, de remplissage, de bouchonnage et de conditionnement industriel. Grâce à une expertise locale et des standards internationaux, nous accompagnons les industriels en Tunisie et à l\'export.',
      facts: {
        established: 'Créée en 2007',
        establishedDesc: 'Près de deux décennies d\'excellence',
        local: 'Fabrication 100% Locale',
        localDesc: 'Fabriqué en Tunisie avec fierté',
        export: 'Prêt à l\'Export',
        exportDesc: 'Standards internationaux',
        team: 'Équipe Experte',
        teamDesc: 'Ingénieurs qualifiés'
      },
      imageCaption1: 'Installation de Pointe',
      imageDesc1: 'Fabrication avancée à Nabeul, Tunisie',
      imageCaption2: 'Ingénierie de Précision',
      imageDesc2: 'Savoir-faire de qualité'
    },
    // Products
    products: {
      badge: 'NOS PRODUITS',
      title: 'Solutions Complètes',
      titleAccent: 'de Conditionnement',
      description: 'Des machines individuelles aux lignes de production complètes, adaptées à vos besoins industriels.',
      categories: {
        labeling: 'Machines d\'Étiquetage',
        labelingSub: 'Étiqueteuses',
        labelingDesc: 'Étiquetage haute précision pour bouteilles, pots et contenants. Solutions manuelles à entièrement automatiques.',
        filling: 'Machines de Remplissage',
        fillingSub: 'Remplisseuses',
        fillingDesc: 'Remplissage volumétrique de précision pour liquides, crèmes, gels. Parfait pour cosmétiques et pharma.',
        capping: 'Bouchonnage & Sertissage',
        cappingSub: 'Bouchonneuses',
        cappingDesc: 'Bouchonnage automatisé pour fermetures sécurisées et étanches. Compatible avec tous types de bouchons.',
        complete: 'Lignes Complètes',
        completeSub: 'Lignes de Conditionnement',
        completeDesc: 'Solutions clé en main intégrées. Automatisation complète du remplissage au conditionnement.'
      },
      features: {
        labeling: ['Étiquetage 360°', 'Multi-format', 'Contrôle vitesse'],
        filling: ['Contrôle Volumétrique', 'Nettoyage Facile', 'Multi-viscosité'],
        capping: ['Contrôle de Couple', 'Changement Rapide', 'Construction Durable'],
        complete: ['Automatisation Totale', 'Intégration Personnalisée', 'Évolutif']
      },
      cta: 'Découvrir Plus'
    },
    // Featured
    featured: {
      badge: 'ÉQUIPEMENTS PHARES',
      title: 'Nos Machines',
      titleAccent: 'Phares',
      taglines: {
        precision: 'Précision et Efficacité',
        volumetric: 'Excellence Volumétrique',
        integration: 'Intégration Totale'
      },
      specs: {
        speed: 'Vitesse',
        diameter: 'Diamètre',
        precision: 'Précision',
        volume: 'Volume',
        accuracy: 'Exactitude',
        output: 'Production',
        automation: 'Automatisation',
        design: 'Design'
      },
      industries: 'Industries Applicables',
      custom: 'Personnalisable',
      fast: 'Rapide',
      durable: 'Durable'
    },
    // Industries
    industries: {
      badge: 'SECTEURS DESSERVIS',
      title: 'De Confiance Dans',
      titleAccent: 'Multiples Secteurs',
      description: 'Solutions polyvalentes avec configurations personnalisées pour chaque industrie.',
      list: {
        agrofood: 'Agro-alimentaire',
        agrofoodDesc: 'Conditionnement alimentaire',
        cosmetics: 'Cosmétique',
        cosmeticsDesc: 'Beauté & soins personnels',
        pharma: 'Pharmaceutique',
        pharmaDesc: 'Conditionnement médical',
        chemicals: 'Chimie',
        chemicalsDesc: 'Remplissage de produits chimiques',
        beverages: 'Brasserie',
        beveragesDesc: 'Embouteillage & étiquetage',
        petcare: 'Produits Animaliers',
        petcareDesc: 'Produits vétérinaires',
        wellness: 'Parapharmacie',
        wellnessDesc: 'Compléments santé'
      }
    },
    // Why Choose
    whyChoose: {
      badge: 'POURQUOI ZAYANI',
      title: 'L\'Avantage',
      titleAccent: 'Zayani',
      description: 'Le savoir-faire tunisien aux standards internationaux pour une valeur exceptionnelle.',
      benefits: {
        durable: 'Robuste et Durable',
        durableDesc: 'Construction industrielle avec matériaux premium pour des décennies de fonctionnement fiable.',
        simple: 'Facile à Utiliser',
        simpleDesc: 'Commandes intuitives et interfaces conviviales nécessitant un temps de formation minimal.',
        custom: 'Entièrement Personnalisable',
        customDesc: 'Designs modulaires qui s\'adaptent à vos spécifications exactes et besoins de production.',
        support: 'Expertise Locale',
        supportDesc: 'Équipe de support tunisienne dédiée offrant une réponse rapide et une assistance experte.'
      },
      stats: {
        title: 'Bilan Prouvé',
        subtitle: 'Des chiffres qui parlent d\'eux-mêmes',
        years: 'Ans d\'Activité',
        installed: 'Machines Installées',
        satisfaction: 'Satisfaction Client',
        available: 'Support Disponible'
      }
    },
    // Contact
    contact: {
      badge: 'CONTACTEZ-NOUS',
      title: 'Commençons une',
      titleAccent: 'Conversation',
      description: 'Prêt à moderniser votre ligne de production ? Obtenez une consultation personnalisée dès aujourd\'hui.',
      info: {
        visit: 'Visitez-Nous',
        call: 'Appelez-Nous',
        email: 'Écrivez-Nous'
      },
      hours: {
        title: 'Horaires d\'Ouverture',
        weekdays: 'Lundi - Vendredi',
        saturday: 'Samedi',
        sunday: 'Dimanche',
        closed: 'Fermé'
      },
      form: {
        name: 'Nom Complet',
        company: 'Société',
        email: 'Email',
        phone: 'Téléphone',
        message: 'Votre Message',
        required: '*',
        submit: 'Envoyer la Demande',
        success: 'Merci !',
        successMsg: 'Votre demande a été envoyée avec succès. Nous vous répondrons dans les 24 heures.'
      }
    },
    // Footer
    footer: {
      tagline: 'Excellence Industrielle',
      description: 'Principal fabricant tunisien de machines industrielles de conditionnement, d\'étiquetage, de remplissage et de bouchonnage depuis 2007.',
      quickLinks: 'Liens Rapides',
      products: 'Nos Produits',
      productList: {
        labeling: 'Machines d\'Étiquetage',
        filling: 'Machines de Remplissage',
        capping: 'Systèmes de Bouchonnage',
        complete: 'Lignes Complètes',
        custom: 'Solutions Personnalisées'
      },
      contactUs: 'Contactez-Nous',
      copyright: '© 2026 Zayani C.M.E. Tous droits réservés. Fabriqué avec précision en Tunisie.',
      legal: {
        privacy: 'Politique de Confidentialité',
        terms: 'Conditions d\'Utilisation',
        cookies: 'Politique de Cookies'
      }
    },
    // Quote Modal
    quote: {
      title: 'Demander un Devis',
      subtitle: 'Remplissez le formulaire ci-dessous et notre équipe vous contactera rapidement.',
      machine: 'Machine',
      category: 'Catégorie',
      form: {
        name: 'Nom',
        company: 'Société',
        email: 'Email',
        phone: 'Téléphone',
        country: 'Pays',
        message: 'Message',
        submit: 'Envoyer la Demande',
        cancel: 'Annuler'
      },
      success: 'Demande Envoyée',
      successMsg: 'Merci pour votre demande. Notre équipe vous contactera sous 24 heures.'
    },
    // Machine Detail
    machineDetail: {
      quote: 'Demander un devis pour cette machine',
      specs: 'Caractéristiques Techniques',
      applications: 'Applications',
      backToMachines: 'Retour aux Machines'
    }
  },
  en: {
    // Navigation
    nav: {
      home: 'Home',
      about: 'About',
      machines: 'Machines',
      sectors: 'Sectors',
      services: 'Services',
      contact: 'Contact'
    },
    // Hero
    hero: {
      badge: 'Proudly Made in Tunisia Since 2007',
      title: 'Industrial Packaging & Labeling Machines',
      subtitle: 'Manual, semi-automatic, and automatic solutions to optimize your production line',
      cta1: 'View Machines',
      cta2: 'Request Quote',
      stats: {
        years: 'Years Excellence',
        machines: 'Machines Deployed',
        local: 'Local Fabrication',
        support: 'Support'
      }
    },
    // About
    about: {
      badge: 'WHO WE ARE',
      title: 'Engineering Excellence',
      titleAccent: 'Since 2007',
      description: 'Founded in 2007 in Nabeul, Tunisia — Zayani C.M.E designs and manufactures industrial labeling, filling, capping and packaging machines. With local expertise and international standards, we support manufacturers in Tunisia and for export.',
      facts: {
        established: 'Established 2007',
        establishedDesc: 'Nearly two decades of excellence',
        local: '100% Local Manufacturing',
        localDesc: 'Made in Tunisia with pride',
        export: 'Export-Ready',
        exportDesc: 'International standards',
        team: 'Expert Team',
        teamDesc: 'Skilled engineers'
      },
      imageCaption1: 'State-of-the-Art Facility',
      imageDesc1: 'Advanced manufacturing in Nabeul, Tunisia',
      imageCaption2: 'Precision Engineering',
      imageDesc2: 'Quality craftsmanship'
    },
    // Products
    products: {
      badge: 'OUR PRODUCTS',
      title: 'Complete Packaging',
      titleAccent: 'Solutions',
      description: 'From individual machines to complete production lines, tailored to your industry needs.',
      categories: {
        labeling: 'Labeling Machines',
        labelingSub: 'Labelers',
        labelingDesc: 'High-precision labeling for bottles, jars and containers. Manual to fully automatic solutions.',
        filling: 'Filling Machines',
        fillingSub: 'Fillers',
        fillingDesc: 'Precision volumetric filling for liquids, creams, gels. Perfect for cosmetics and pharma.',
        capping: 'Capping & Sealing',
        cappingSub: 'Cappers',
        cappingDesc: 'Automated capping for secure, leak-proof closures. Compatible with all cap types.',
        complete: 'Complete Lines',
        completeSub: 'Packaging Lines',
        completeDesc: 'Integrated turnkey solutions. Full automation from filling to packaging.'
      },
      features: {
        labeling: ['360° Labeling', 'Multi-format', 'Speed Control'],
        filling: ['Volumetric Control', 'Easy Clean', 'Multi-viscosity'],
        capping: ['Torque Control', 'Quick Change', 'Durable Build'],
        complete: ['Full Automation', 'Custom Integration', 'Scalable']
      },
      cta: 'Discover More'
    },
    // Featured
    featured: {
      badge: 'FEATURED EQUIPMENT',
      title: 'Our Flagship',
      titleAccent: 'Machines',
      taglines: {
        precision: 'Precision Meets Efficiency',
        volumetric: 'Volumetric Excellence',
        integration: 'Total Integration'
      },
      specs: {
        speed: 'Speed',
        diameter: 'Diameter',
        precision: 'Precision',
        volume: 'Volume',
        accuracy: 'Accuracy',
        output: 'Output',
        automation: 'Automation',
        design: 'Design'
      },
      industries: 'Applicable Industries',
      custom: 'Customizable',
      fast: 'Fast',
      durable: 'Durable'
    },
    // Industries
    industries: {
      badge: 'INDUSTRIES WE SERVE',
      title: 'Trusted Across',
      titleAccent: 'Multiple Sectors',
      description: 'Versatile machinery solutions with customized configurations for every industry.',
      list: {
        agrofood: 'Agro-food',
        agrofoodDesc: 'Food packaging & bottling',
        cosmetics: 'Cosmetics',
        cosmeticsDesc: 'Beauty & personal care',
        pharma: 'Pharmaceutical',
        pharmaDesc: 'Medical-grade packaging',
        chemicals: 'Chemicals',
        chemicalsDesc: 'Chemical product filling',
        beverages: 'Beverages',
        beveragesDesc: 'Bottling & labeling',
        petcare: 'Pet Care',
        petcareDesc: 'Veterinary products',
        wellness: 'Wellness',
        wellnessDesc: 'Health supplements'
      }
    },
    // Why Choose
    whyChoose: {
      badge: 'WHY ZAYANI',
      title: 'The Zayani',
      titleAccent: 'Advantage',
      description: 'Tunisian craftsmanship meets international standards to deliver exceptional value.',
      benefits: {
        durable: 'Built to Last',
        durableDesc: 'Industrial-grade construction with premium materials for decades of reliable operation.',
        simple: 'Simple Operation',
        simpleDesc: 'Intuitive controls and user-friendly interfaces requiring minimal training time.',
        custom: 'Fully Customizable',
        customDesc: 'Modular designs that adapt to your exact specifications and production needs.',
        support: 'Local Expertise',
        supportDesc: 'Dedicated Tunisian support team providing rapid response and expert assistance.'
      },
      stats: {
        title: 'Proven Track Record',
        subtitle: 'Numbers that speak for themselves',
        years: 'Years in Business',
        installed: 'Machines Installed',
        satisfaction: 'Client Satisfaction',
        available: 'Support Available'
      }
    },
    // Contact
    contact: {
      badge: 'GET IN TOUCH',
      title: 'Let\'s Start a',
      titleAccent: 'Conversation',
      description: 'Ready to upgrade your production line? Get a personalized consultation today.',
      info: {
        visit: 'Visit Us',
        call: 'Call Us',
        email: 'Email Us'
      },
      hours: {
        title: 'Business Hours',
        weekdays: 'Monday - Friday',
        saturday: 'Saturday',
        sunday: 'Sunday',
        closed: 'Closed'
      },
      form: {
        name: 'Full Name',
        company: 'Company',
        email: 'Email',
        phone: 'Phone',
        message: 'Your Message',
        required: '*',
        submit: 'Send Request',
        success: 'Thank You!',
        successMsg: 'Your request has been submitted successfully. We\'ll get back to you within 24 hours.'
      }
    },
    // Footer
    footer: {
      tagline: 'Industrial Excellence',
      description: 'Leading Tunisian manufacturer of industrial packaging, labeling, filling, and capping machinery since 2007.',
      quickLinks: 'Quick Links',
      products: 'Our Products',
      productList: {
        labeling: 'Labeling Machines',
        filling: 'Filling Machines',
        capping: 'Capping Systems',
        complete: 'Complete Lines',
        custom: 'Custom Solutions'
      },
      contactUs: 'Contact Us',
      copyright: '© 2026 Zayani C.M.E. All rights reserved. Crafted with precision in Tunisia.',
      legal: {
        privacy: 'Privacy Policy',
        terms: 'Terms of Service',
        cookies: 'Cookie Policy'
      }
    },
    // Quote Modal
    quote: {
      title: 'Request a Quote',
      subtitle: 'Fill out the form below and our team will contact you promptly.',
      machine: 'Machine',
      category: 'Category',
      form: {
        name: 'Name',
        company: 'Company',
        email: 'Email',
        phone: 'Phone',
        country: 'Country',
        message: 'Message',
        submit: 'Send Request',
        cancel: 'Cancel'
      },
      success: 'Request Sent',
      successMsg: 'Thank you for your request. Our team will contact you within 24 hours.'
    },
    // Machine Detail
    machineDetail: {
      quote: 'Request a quote for this machine',
      specs: 'Technical Specifications',
      applications: 'Applications',
      backToMachines: 'Back to Machines'
    }
  },
  ar: {
    // Navigation
    nav: {
      home: 'الرئيسية',
      about: 'من نحن',
      machines: 'الآلات',
      sectors: 'القطاعات',
      services: 'الخدمات',
      contact: 'اتصل بنا'
    },
    // Hero
    hero: {
      badge: 'مصنوعة بفخر في تونس منذ 2007',
      title: 'آلات التعبئة والتغليف ووضع الملصقات الصناعية',
      subtitle: 'حلول يدوية وشبه أوتوماتيكية وأوتوماتيكية لتحسين خط الإنتاج الخاص بك',
      cta1: 'عرض الآلات',
      cta2: 'طلب عرض أسعار',
      stats: {
        years: 'سنوات من التميز',
        machines: 'آلة تم نشرها',
        local: 'تصنيع محلي',
        support: 'الدعم'
      }
    },
    // About
    about: {
      badge: 'من نحن',
      title: 'التميز الهندسي',
      titleAccent: 'منذ 2007',
      description: 'تأسست في عام 2007 في نابل، تونس - تصمم وتصنع Zayani C.M.E آلات وضع الملصقات والتعبئة والإغلاق والتعبئة الصناعية. بفضل الخبرة المحلية والمعايير الدولية، ندعم المصنعين في تونس وللتصدير.',
      facts: {
        established: 'تأسست عام 2007',
        establishedDesc: 'ما يقرب من عقدين من التميز',
        local: 'تصنيع محلي 100%',
        localDesc: 'صنع في تونس بفخر',
        export: 'جاهز للتصدير',
        exportDesc: 'معايير دولية',
        team: 'فريق خبير',
        teamDesc: 'مهندسون ماهرون'
      },
      imageCaption1: 'منشأة حديثة',
      imageDesc1: 'تصنيع متقدم في نابل، تونس',
      imageCaption2: 'هندسة دقيقة',
      imageDesc2: 'صنعة عالية الجودة'
    },
    // Products
    products: {
      badge: 'منتجاتنا',
      title: 'حلول التعبئة',
      titleAccent: 'الكاملة',
      description: 'من الآلات الفردية إلى خطوط الإنتاج الكاملة، مصممة خصيصًا لاحتياجات صناعتك.',
      categories: {
        labeling: 'آلات وضع الملصقات',
        labelingSub: 'آلات اللصق',
        labelingDesc: 'وضع ملصقات عالي الدقة للزجاجات والبرطمانات والحاويات. حلول من اليدوية إلى الأوتوماتيكية بالكامل.',
        filling: 'آلات التعبئة',
        fillingSub: 'آلات الملء',
        fillingDesc: 'تعبئة حجمية دقيقة للسوائل والكريمات والجل. مثالية لمستحضرات التجميل والأدوية.',
        capping: 'الإغلاق والختم',
        cappingSub: 'آلات الإغلاق',
        cappingDesc: 'إغلاق آلي لإغلاقات آمنة ومقاومة للتسرب. متوافق مع جميع أنواع الأغطية.',
        complete: 'خطوط كاملة',
        completeSub: 'خطوط التعبئة',
        completeDesc: 'حلول متكاملة جاهزة. أتمتة كاملة من التعبئة إلى التغليف.'
      },
      features: {
        labeling: ['لصق 360 درجة', 'متعدد الأشكال', 'التحكم في السرعة'],
        filling: ['التحكم الحجمي', 'تنظيف سهل', 'متعدد اللزوجة'],
        capping: ['التحكم في عزم الدوران', 'تغيير سريع', 'بناء متين'],
        complete: ['أتمتة كاملة', 'تكامل مخصص', 'قابل للتوسع']
      },
      cta: 'اكتشف المزيد'
    },
    // Featured
    featured: {
      badge: 'المعدات المميزة',
      title: 'آلاتنا',
      titleAccent: 'الرائدة',
      taglines: {
        precision: 'الدقة تلتقي بالكفاءة',
        volumetric: 'التميز الحجمي',
        integration: 'التكامل الكامل'
      },
      specs: {
        speed: 'السرعة',
        diameter: 'القطر',
        precision: 'الدقة',
        volume: 'الحجم',
        accuracy: 'الدقة',
        output: 'الإنتاج',
        automation: 'الأتمتة',
        design: 'التصميم'
      },
      industries: 'الصناعات المطبقة',
      custom: 'قابل للتخصيص',
      fast: 'سريع',
      durable: 'متين'
    },
    // Industries
    industries: {
      badge: 'الصناعات التي نخدمها',
      title: 'موثوق به في',
      titleAccent: 'قطاعات متعددة',
      description: 'حلول آلات متعددة الاستخدامات مع تكوينات مخصصة لكل صناعة.',
      list: {
        agrofood: 'الصناعات الغذائية',
        agrofoodDesc: 'تعبئة الأغذية والتعبئة',
        cosmetics: 'مستحضرات التجميل',
        cosmeticsDesc: 'الجمال والعناية الشخصية',
        pharma: 'الأدوية',
        pharmaDesc: 'التعبئة الطبية',
        chemicals: 'المواد الكيميائية',
        chemicalsDesc: 'تعبئة المنتجات الكيميائية',
        beverages: 'المشروبات',
        beveragesDesc: 'التعبئة ووضع الملصقات',
        petcare: 'العناية بالحيوانات',
        petcareDesc: 'المنتجات البيطرية',
        wellness: 'الصحة',
        wellnessDesc: 'المكملات الصحية'
      }
    },
    // Why Choose
    whyChoose: {
      badge: 'لماذا زياني',
      title: 'ميزة',
      titleAccent: 'زياني',
      description: 'الحرفية التونسية تلتقي بالمعايير الدولية لتقديم قيمة استثنائية.',
      benefits: {
        durable: 'مصمم للاستمرار',
        durableDesc: 'بناء صناعي بمواد متميزة لعقود من التشغيل الموثوق.',
        simple: 'سهل الاستخدام',
        simpleDesc: 'عناصر تحكم بديهية وواجهات سهلة الاستخدام تتطلب وقت تدريب ضئيل.',
        custom: 'قابل للتخصيص بالكامل',
        customDesc: 'تصاميم نمطية تتكيف مع مواصفاتك الدقيقة واحتياجات الإنتاج.',
        support: 'خبرة محلية',
        supportDesc: 'فريق دعم تونسي مخصص يوفر استجابة سريعة ومساعدة خبيرة.'
      },
      stats: {
        title: 'سجل حافل',
        subtitle: 'أرقام تتحدث عن نفسها',
        years: 'سنوات في العمل',
        installed: 'آلات مثبتة',
        satisfaction: 'رضا العملاء',
        available: 'الدعم متاح'
      }
    },
    // Contact
    contact: {
      badge: 'اتصل بنا',
      title: 'لنبدأ',
      titleAccent: 'محادثة',
      description: 'هل أنت مستعد لتطوير خط الإنتاج الخاص بك؟ احصل على استشارة شخصية اليوم.',
      info: {
        visit: 'زرنا',
        call: 'اتصل بنا',
        email: 'راسلنا'
      },
      hours: {
        title: 'ساعات العمل',
        weekdays: 'الاثنين - الجمعة',
        saturday: 'السبت',
        sunday: 'الأحد',
        closed: 'مغلق'
      },
      form: {
        name: 'الاسم الكامل',
        company: 'الشركة',
        email: 'البريد الإلكتروني',
        phone: 'الهاتف',
        message: 'رسالتك',
        required: '*',
        submit: 'إرسال الطلب',
        success: 'شكراً لك!',
        successMsg: 'تم إرسال طلبك بنجاح. سنعاود الاتصال بك خلال 24 ساعة.'
      }
    },
    // Footer
    footer: {
      tagline: 'التميز الصناعي',
      description: 'الشركة التونسية الرائدة في تصنيع آلات التعبئة والتغليف ووضع الملصقات والتعبئة والإغلاق الصناعية منذ عام 2007.',
      quickLinks: 'روابط سريعة',
      products: 'منتجاتنا',
      productList: {
        labeling: 'آلات وضع الملصقات',
        filling: 'آلات التعبئة',
        capping: 'أنظمة الإغلاق',
        complete: 'خطوط كاملة',
        custom: 'حلول مخصصة'
      },
      contactUs: 'اتصل بنا',
      copyright: '© 2026 زياني C.M.E. جميع الحقوق محفوظة. صنع بدقة في تونس.',
      legal: {
        privacy: 'سياسة الخصوصية',
        terms: 'شروط الخدمة',
        cookies: 'سياسة ملفات تعريف الارتباط'
      }
    },
    // Quote Modal
    quote: {
      title: 'طلب عرض أسعار',
      subtitle: 'املأ النموذج أدناه وسيتصل بك فريقنا على الفور.',
      machine: 'الآلة',
      category: 'الفئة',
      form: {
        name: 'الاسم',
        company: 'الشركة',
        email: 'البريد الإلكتروني',
        phone: 'الهاتف',
        country: 'البلد',
        message: 'الرسالة',
        submit: 'إرسال الطلب',
        cancel: 'إلغاء'
      },
      success: 'تم إرسال الطلب',
      successMsg: 'شكرًا لك على طلبك. سيتصل بك فريقنا خلال 24 ساعة.'
    },
    // Machine Detail
    machineDetail: {
      quote: 'طلب عرض أسعار لهذه الآلة',
      specs: 'المواصفات الفنية',
      applications: 'التطبيقات',
      backToMachines: 'العودة إلى الآلات'
    }
  }
};
