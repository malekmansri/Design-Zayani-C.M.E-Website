export interface Machine {
  id: string;
  model: string;
  name: {
    fr: string;
    en: string;
    ar: string;
  };
  category: 'etiqueteuses' | 'remplisseuses' | 'bouchonneuses' | 'lignes-completes';
  subcategory?: string;
  description: {
    fr: string;
    en: string;
    ar: string;
  };
  image: string;
  specs: {
    fr: string[];
    en: string[];
    ar: string[];
  };
  applications: {
    fr: string[];
    en: string[];
    ar: string[];
  };
  features: {
    fr: string[];
    en: string[];
    ar: string[];
  };
  featured?: boolean;
}

export const machines: Machine[] = [
  // ÉTIQUETEUSES - Labeling Machines
  {
    id: 'cme-350m',
    model: 'CME 350M',
    category: 'etiqueteuses',
    subcategory: 'Manuelle',
    name: {
      fr: 'Étiqueteuse Manuelle',
      en: 'Manual Labeling Machine',
      ar: 'آلة لصق الملصقات اليدوية'
    },
    description: {
      fr: 'Étiqueteuse manuelle économique et robuste, idéale pour petites productions et artisans. Construction simple facilitant l\'entretien et l\'utilisation quotidienne.',
      en: 'Economical and robust manual labeling machine, ideal for small productions and artisans. Simple construction facilitating daily maintenance and use.',
      ar: 'آلة لصق ملصقات يدوية اقتصادية ومتينة، مثالية للإنتاج الصغير والحرفيين. بناء بسيط يسهل الصيانة والاستخدام اليومي.'
    },
    image: 'https://images.unsplash.com/photo-1522753071498-f3137a65aee3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYWJlbGluZyUyMG1hY2hpbmUlMjBmYWN0b3J5fGVufDF8fHx8MTc2ODY4NjE0NXww&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Vitesse: 300-500 bouteilles/heure',
        'Diamètre: 20-100mm',
        'Hauteur bouteille: 50-300mm',
        'Largeur étiquette: 20-150mm'
      ],
      en: [
        'Speed: 300-500 bottles/hour',
        'Diameter: 20-100mm',
        'Bottle height: 50-300mm',
        'Label width: 20-150mm'
      ],
      ar: [
        'السرعة: 300-500 زجاجة/ساعة',
        'القطر: 20-100 ملم',
        'ارتفاع الزجاجة: 50-300 ملم',
        'عرض الملصق: 20-150 ملم'
      ]
    },
    applications: {
      fr: ['Artisanat', 'Petites entreprises', 'Production pilote', 'Cosmétique artisanale'],
      en: ['Artisan', 'Small businesses', 'Pilot production', 'Artisan cosmetics'],
      ar: ['الحرف اليدوية', 'الشركات الصغيرة', 'الإنتاج التجريبي', 'مستحضرات التجميل الحرفية']
    },
    features: {
      fr: ['Construction robuste acier inoxydable', 'Faible coût de maintenance', 'Facile à utiliser', 'Compact et mobile'],
      en: ['Robust stainless steel construction', 'Low maintenance cost', 'Easy to use', 'Compact and mobile'],
      ar: ['بناء فولاذي مقاوم للصدأ', 'تكلفة صيانة منخفضة', 'سهل الاستخدام', 'مدمج ومتنقل']
    }
  },
  {
    id: 'cme-361t',
    model: 'CME 361T',
    category: 'etiqueteuses',
    subcategory: 'Semi-automatique',
    name: {
      fr: 'Étiqueteuse Semi-Automatique',
      en: 'Semi-Automatic Labeling Machine',
      ar: 'آلة لصق الملصقات شبه الأوتوماتيكية'
    },
    description: {
      fr: 'Machine d\'étiquetage semi-automatique pour bouteilles cylindriques et contenants. Idéale pour petites et moyennes productions avec haute précision et facilité d\'utilisation.',
      en: 'Semi-automatic labeling machine for cylindrical bottles and containers. Ideal for small to medium production runs with high precision and ease of use.',
      ar: 'آلة لصق ملصقات شبه أوتوماتيكية للزجاجات الأسطوانية والحاويات. مثالية للإنتاج الصغير والمتوسط بدقة عالية وسهولة في الاستخدام.'
    },
    image: 'https://images.unsplash.com/photo-1522753071498-f3137a65aee3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYWJlbGluZyUyMG1hY2hpbmUlMjBmYWN0b3J5fGVufDF8fHx8MTc2ODY4NjE0NXww&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Vitesse: Jusqu\'à 1 500 bouteilles/heure',
        'Diamètre bouteille: 30-120mm',
        'Largeur étiquette: 20-300mm',
        'Précision: ±0.5mm'
      ],
      en: [
        'Speed: Up to 1,500 bottles/hour',
        'Bottle diameter: 30-120mm',
        'Label width: 20-300mm',
        'Precision: ±0.5mm'
      ],
      ar: [
        'السرعة: حتى 1500 زجاجة/ساعة',
        'قطر الزجاجة: 30-120 ملم',
        'عرض الملصق: 20-300 ملم',
        'الدقة: ±0.5 ملم'
      ]
    },
    applications: {
      fr: ['Cosmétique', 'Pharmaceutique', 'Agroalimentaire', 'Chimie'],
      en: ['Cosmetics', 'Pharmaceutical', 'Food & Beverage', 'Chemicals'],
      ar: ['مستحضرات التجميل', 'الأدوية', 'الأغذية والمشروبات', 'المواد الكيميائية']
    },
    features: {
      fr: ['Étiquetage précis 360°', 'Réglage rapide', 'Interface intuitive', 'Système de détection automatique'],
      en: ['Precise 360° labeling', 'Quick adjustment', 'Intuitive interface', 'Automatic detection system'],
      ar: ['لصق دقيق 360 درجة', 'ضبط سريع', 'واجهة بديهية', 'نظام كشف تلقائي']
    },
    featured: true
  },
  {
    id: 'cme-362t',
    model: 'CME 362T',
    category: 'etiqueteuses',
    subcategory: 'Semi-automatique',
    name: {
      fr: 'Étiqueteuse Semi-Auto Double Face',
      en: 'Semi-Auto Double-Sided Labeling Machine',
      ar: 'آلة لصق الملصقات شبه الأوتوماتيكية وجهين'
    },
    description: {
      fr: 'Étiqueteuse semi-automatique capable d\'appliquer des étiquettes sur deux faces simultanément. Parfaite pour bouteilles plates et produits rectangulaires.',
      en: 'Semi-automatic labeling machine capable of applying labels on two sides simultaneously. Perfect for flat bottles and rectangular products.',
      ar: 'آلة لصق ملصقات شبه أوتوماتيكية قادرة على وضع الملصقات على وجهين في نفس الوقت. مثالية للزجاجات المسطحة والمنتجات المستطيلة.'
    },
    image: 'https://images.unsplash.com/photo-1764745021344-317b80f09e40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwcGFja2FnaW5nJTIwbWFjaGluZXxlbnwxfHx8fDE3Njg2ODYxNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Vitesse: 800-1200 produits/heure',
        'Format: Rectangulaire et plat',
        'Double face simultané',
        'Précision: ±1mm'
      ],
      en: [
        'Speed: 800-1200 products/hour',
        'Format: Rectangular and flat',
        'Simultaneous double-sided',
        'Precision: ±1mm'
      ],
      ar: [
        'السرعة: 800-1200 منتج/ساعة',
        'الشكل: مستطيل ومسطح',
        'وجهين في نفس الوقت',
        'الدقة: ±1 ملم'
      ]
    },
    applications: {
      fr: ['Bouteilles plates', 'Produits rectangulaires', 'Cosmétique', 'Alimentaire'],
      en: ['Flat bottles', 'Rectangular products', 'Cosmetics', 'Food'],
      ar: ['زجاجات مسطحة', 'منتجات مستطيلة', 'مستحضرات التجميل', 'الأغذية']
    },
    features: {
      fr: ['Étiquetage recto-verso', 'Changement format rapide', 'Haute précision', 'Construction robuste'],
      en: ['Front-back labeling', 'Quick format change', 'High precision', 'Robust construction'],
      ar: ['لصق أمامي وخلفي', 'تغيير سريع للشكل', 'دقة عالية', 'بناء متين']
    }
  },
  {
    id: 'cme-365a',
    model: 'CME 365A',
    category: 'etiqueteuses',
    subcategory: 'Automatique',
    name: {
      fr: 'Étiqueteuse Automatique Haute Cadence',
      en: 'High-Speed Automatic Labeling Machine',
      ar: 'آلة لصق الملصقات الأوتوماتيكية عالية السرعة'
    },
    description: {
      fr: 'Étiqueteuse automatique haute performance pour productions industrielles intensives. Gestion multi-formats avec changement rapide et système de contrôle qualité intégré.',
      en: 'High-performance automatic labeling machine for intensive industrial productions. Multi-format handling with quick changeover and integrated quality control system.',
      ar: 'آلة لصق ملصقات أوتوماتيكية عالية الأداء للإنتاج الصناعي المكثف. معالجة متعددة الأشكال مع تغيير سريع ونظام مراقبة جودة متكامل.'
    },
    image: 'https://images.unsplash.com/photo-1739863306113-2629b0ed2a6b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWN0b3J5JTIwcHJvZHVjdGlvbiUyMGxpbmV8ZW58MXx8fHwxNzY4NjYyMjk2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Vitesse: Jusqu\'à 3 500 bouteilles/heure',
        'Étiquetage 360° rotatif',
        'Système de vision intégré',
        'Interface tactile couleur 10"'
      ],
      en: [
        'Speed: Up to 3,500 bottles/hour',
        '360° rotary labeling',
        'Integrated vision system',
        '10" color touch interface'
      ],
      ar: [
        'السرعة: حتى 3500 زجاجة/ساعة',
        'لصق دوراني 360 درجة',
        'نظام رؤية متكامل',
        'واجهة تعمل باللمس ملونة 10 بوصة'
      ]
    },
    applications: {
      fr: ['Pharmaceutique', 'Cosmétique haut volume', 'Chimie', 'Brasserie'],
      en: ['Pharmaceutical', 'High-volume cosmetics', 'Chemicals', 'Beverages'],
      ar: ['الأدوية', 'مستحضرات التجميل عالية الحجم', 'المواد الكيميائية', 'المشروبات']
    },
    features: {
      fr: ['Contrôle qualité vision', 'Rejet automatique défauts', 'Multi-formats', 'Traçabilité production'],
      en: ['Vision quality control', 'Automatic defect rejection', 'Multi-format', 'Production traceability'],
      ar: ['مراقبة جودة الرؤية', 'رفض تلقائي للعيوب', 'متعدد الأشكال', 'تتبع الإنتاج']
    },
    featured: true
  },
  {
    id: 'cme-368a',
    model: 'CME 368A',
    category: 'etiqueteuses',
    subcategory: 'Automatique',
    name: {
      fr: 'Étiqueteuse Automatique Multi-Postes',
      en: 'Multi-Station Automatic Labeling Machine',
      ar: 'آلة لصق الملصقات الأوتوماتيكية متعددة المحطات'
    },
    description: {
      fr: 'Système d\'étiquetage automatique multi-postes permettant l\'application de plusieurs étiquettes (avant, arrière, col) en un seul passage. Solution complète pour étiquetage complexe.',
      en: 'Multi-station automatic labeling system allowing the application of multiple labels (front, back, neck) in a single pass. Complete solution for complex labeling.',
      ar: 'نظام لصق ملصقات أوتوماتيكي متعدد المحطات يسمح بتطبيق ملصقات متعددة (أمامي، خلفي، عنق) في تمريرة واحدة. حل كامل للصق المعقد.'
    },
    image: 'https://images.unsplash.com/photo-1733683296842-c5c32fe36a50?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwbWFjaGluZXJ5JTIwbWV0YWx8ZW58MXx8fHwxNzY4NjQ4MjMwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Vitesse: 2 500 bouteilles/heure',
        'Jusqu\'à 4 postes d\'étiquetage',
        'Synchronisation automatique',
        'Convoyeur intégré'
      ],
      en: [
        'Speed: 2,500 bottles/hour',
        'Up to 4 labeling stations',
        'Automatic synchronization',
        'Integrated conveyor'
      ],
      ar: [
        'السرعة: 2500 زجاجة/ساعة',
        'حتى 4 محطات لصق',
        'مزامنة تلقائية',
        'ناقل متكامل'
      ]
    },
    applications: {
      fr: ['Vins et spiritueux', 'Cosmétique premium', 'Pharmaceutique', 'Agroalimentaire'],
      en: ['Wines and spirits', 'Premium cosmetics', 'Pharmaceutical', 'Agro-food'],
      ar: ['النبيذ والمشروبات الروحية', 'مستحضرات التجميل الفاخرة', 'الأدوية', 'الصناعات الغذائية']
    },
    features: {
      fr: ['Multi-étiquettes simultané', 'Positionnement précis', 'Interface programmable', 'Maintenance facilitée'],
      en: ['Simultaneous multi-label', 'Precise positioning', 'Programmable interface', 'Easy maintenance'],
      ar: ['ملصقات متعددة في نفس الوقت', 'تحديد موضع دقيق', 'واجهة قابلة للبرمجة', 'صيانة سهلة']
    }
  },

  // REMPLISSEUSES - Filling Machines
  {
    id: 'cme-420r',
    model: 'CME 420R',
    category: 'remplisseuses',
    subcategory: 'Liquides',
    name: {
      fr: 'Remplisseuse pour Liquides',
      en: 'Liquid Filling Machine',
      ar: 'آلة تعبئة السوائل'
    },
    description: {
      fr: 'Remplisseuse volumétrique pour liquides de toutes viscosités. Système de dosage précis avec pompes volumétriques et nettoyage CIP compatible.',
      en: 'Volumetric filling machine for liquids of all viscosities. Precise dosing system with volumetric pumps and CIP cleaning compatible.',
      ar: 'آلة تعبئة حجمية للسوائل بجميع اللزوجات. نظام جرعات دقيق مع مضخات حجمية ومتوافق مع التنظيف CIP.'
    },
    image: 'https://images.unsplash.com/photo-1701448149957-b96dbd1926ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaWxsaW5nJTIwbWFjaGluZSUyMHByb2R1Y3Rpb258ZW58MXx8fHwxNzY4Njg2MTQ3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Débit: 20-100 ml/cycle',
        'Nombre de têtes: 2-6 têtes',
        'Précision: ±0.5%',
        'Viscosité: 1-5000 cps'
      ],
      en: [
        'Flow rate: 20-100 ml/cycle',
        'Number of heads: 2-6 heads',
        'Precision: ±0.5%',
        'Viscosity: 1-5000 cps'
      ],
      ar: [
        'معدل التدفق: 20-100 مل/دورة',
        'عدد الرؤوس: 2-6 رؤوس',
        'الدقة: ±0.5%',
        'اللزوجة: 1-5000 سنتيبواز'
      ]
    },
    applications: {
      fr: ['Agroalimentaire', 'Brasserie', 'Chimie liquide', 'Produits d\'entretien'],
      en: ['Agro-food', 'Beverages', 'Liquid chemicals', 'Cleaning products'],
      ar: ['الصناعات الغذائية', 'المشروبات', 'المواد الكيميائية السائلة', 'منتجات التنظيف']
    },
    features: {
      fr: ['Contrôle volumétrique précis', 'Nettoyage CIP', 'Pompes sanitaires', 'Sans goutte anti-drip'],
      en: ['Precise volumetric control', 'CIP cleaning', 'Sanitary pumps', 'Anti-drip system'],
      ar: ['تحكم حجمي دقيق', 'تنظيف CIP', 'مضخات صحية', 'نظام مضاد للتنقيط']
    }
  },
  {
    id: 'cme-430c',
    model: 'CME 430C',
    category: 'remplisseuses',
    subcategory: 'Crèmes',
    name: {
      fr: 'Remplisseuse pour Crèmes et Pâtes',
      en: 'Cream and Paste Filling Machine',
      ar: 'آلة تعبئة الكريمات والمعاجين'
    },
    description: {
      fr: 'Machine spécialisée pour produits visqueux: crèmes, pâtes, gels épais. Système de pompage adapté aux hautes viscosités avec contrôle précis du volume.',
      en: 'Specialized machine for viscous products: creams, pastes, thick gels. Pumping system adapted for high viscosities with precise volume control.',
      ar: 'آلة متخصصة للمنتجات اللزجة: كريمات، معاجين، جل سميك. نظام ضخ مُكيف للزوجة العالية مع التحكم الدقيق في الحجم.'
    },
    image: 'https://images.unsplash.com/photo-1593775832814-3a7829380c7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3NtZXRpY3MlMjBwcm9kdWN0aW9uJTIwZmFjdG9yeXxlbnwxfHx8fDE3Njg2ODYxNDd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Viscosité: Jusqu\'à 50 000 cps',
        'Volume: 5-500 ml',
        'Pompe à piston ou péristaltique',
        'Température contrôlée'
      ],
      en: [
        'Viscosity: Up to 50,000 cps',
        'Volume: 5-500 ml',
        'Piston or peristaltic pump',
        'Temperature controlled'
      ],
      ar: [
        'اللزوجة: حتى 50000 سنتيبواز',
        'الحجم: 5-500 مل',
        'مضخة مكبسية أو تمعجية',
        'درجة حرارة محكومة'
      ]
    },
    applications: {
      fr: ['Cosmétique', 'Pharmaceutique', 'Parapharmacie', 'Produits d\'hygiène'],
      en: ['Cosmetics', 'Pharmaceutical', 'Para-pharmaceutical', 'Hygiene products'],
      ar: ['مستحضرات التجميل', 'الأدوية', 'شبه الصيدلانية', 'منتجات النظافة']
    },
    features: {
      fr: ['Dosage haute viscosité', 'Sans gaspillage', 'Nettoyage facile', 'Chauffage produit optionnel'],
      en: ['High viscosity dosing', 'No waste', 'Easy cleaning', 'Optional product heating'],
      ar: ['جرعات اللزوجة العالية', 'لا يوجد هدر', 'تنظيف سهل', 'تسخين المنتج الاختياري']
    },
    featured: true
  },
  {
    id: 'cme-440a',
    model: 'CME 440A',
    category: 'remplisseuses',
    subcategory: 'Aérosols',
    name: {
      fr: 'Remplisseuse pour Aérosols',
      en: 'Aerosol Filling Machine',
      ar: 'آلة تعبئة الرذاذ'
    },
    description: {
      fr: 'Remplisseuse automatique pour aérosols avec système de remplissage sous pression. Conforme aux normes de sécurité pour produits sous pression.',
      en: 'Automatic aerosol filling machine with pressurized filling system. Compliant with safety standards for pressurized products.',
      ar: 'آلة تعبئة رذاذ أوتوماتيكية مع نظام تعبئة تحت الضغط. متوافقة مع معايير السلامة للمنتجات المضغوطة.'
    },
    image: 'https://images.unsplash.com/photo-1764160454561-0f092320e9e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcHJvY2Vzc2luZyUyMG1hY2hpbmVyeXxlbnwxfHx8fDE3Njg2ODYxNDd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Cadence: 1 200-1 800 unités/heure',
        'Pression: Jusqu\'à 12 bars',
        'Volume: 50-750 ml',
        'Sécurité renforcée'
      ],
      en: [
        'Rate: 1,200-1,800 units/hour',
        'Pressure: Up to 12 bars',
        'Volume: 50-750 ml',
        'Enhanced safety'
      ],
      ar: [
        'المعدل: 1200-1800 وحدة/ساعة',
        'الضغط: حتى 12 بار',
        'الحجم: 50-750 مل',
        'أمان معزز'
      ]
    },
    applications: {
      fr: ['Cosmétique spray', 'Produits techniques', 'Insecticides', 'Désodorisants'],
      en: ['Spray cosmetics', 'Technical products', 'Insecticides', 'Air fresheners'],
      ar: ['مستحضرات التجميل بالرذاذ', 'المنتجات التقنية', 'المبيدات الحشرية', 'معطرات الجو']
    },
    features: {
      fr: ['Remplissage sous pression', 'Système sécurisé', 'Contrôle poids', 'Test étanchéité automatique'],
      en: ['Pressurized filling', 'Secure system', 'Weight control', 'Automatic leak test'],
      ar: ['تعبئة تحت الضغط', 'نظام آمن', 'التحكم في الوزن', 'اختبار تسرب تلقائي']
    }
  },
  {
    id: 'cme-450g',
    model: 'CME 450G',
    category: 'remplisseuses',
    subcategory: 'Gravimétrique',
    name: {
      fr: 'Remplisseuse Gravimétrique',
      en: 'Gravimetric Filling Machine',
      ar: 'آلة التعبئة بالوزن'
    },
    description: {
      fr: 'Remplisseuse de haute précision par pesée gravimétrique. Idéale pour produits de haute valeur nécessitant une exactitude maximale.',
      en: 'High-precision filling machine by gravimetric weighing. Ideal for high-value products requiring maximum accuracy.',
      ar: 'آلة تعبئة عالية الدقة بالوزن. مثالية للمنتجات ذات القيمة العالية التي تتطلب دقة قصوى.'
    },
    image: 'https://images.unsplash.com/photo-1740362381367-09cb98b4e1c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaGFybWFjZXV0aWNhbCUyMG1hbnVmYWN0dXJpbmclMjBlcXVpcG1lbnR8ZW58MXx8fHwxNzY4Njg2MTQ3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Précision: ±0.1%',
        'Balance intégrée haute précision',
        'Vitesse: 600-1200 unités/heure',
        'Traçabilité complète'
      ],
      en: [
        'Precision: ±0.1%',
        'Integrated high-precision scale',
        'Speed: 600-1200 units/hour',
        'Complete traceability'
      ],
      ar: [
        'الدقة: ±0.1%',
        'ميزان متكامل عالي الدقة',
        'السرعة: 600-1200 وحدة/ساعة',
        'تتبع كامل'
      ]
    },
    applications: {
      fr: ['Pharmaceutique', 'Produits de luxe', 'Compléments alimentaires', 'Huiles essentielles'],
      en: ['Pharmaceutical', 'Luxury products', 'Food supplements', 'Essential oils'],
      ar: ['الأدوية', 'منتجات فاخرة', 'المكملات الغذائية', 'الزيوت الأساسية']
    },
    features: {
      fr: ['Pesée en temps réel', 'Rejet automatique hors tolérance', 'Enregistrement données', 'Calibration automatique'],
      en: ['Real-time weighing', 'Automatic out-of-tolerance rejection', 'Data recording', 'Automatic calibration'],
      ar: ['وزن في الوقت الفعلي', 'رفض تلقائي خارج التسامح', 'تسجيل البيانات', 'معايرة تلقائية']
    }
  },

  // BOUCHONNEUSES & SERTISSEUSES - Capping & Sealing
  {
    id: 'cme-510b',
    model: 'CME 510B',
    category: 'bouchonneuses',
    subcategory: 'Automatique',
    name: {
      fr: 'Bouchonneuse Automatique',
      en: 'Automatic Capping Machine',
      ar: 'آلة الإغلاق الأوتوماتيكية'
    },
    description: {
      fr: 'Système de bouchonnage automatique pour tous types de bouchons: vissage, pression, à pompe. Contrôle du couple de serrage pour étanchéité parfaite.',
      en: 'Automatic capping system for all cap types: screw, snap, pump. Torque control for perfect sealing.',
      ar: 'نظام إغلاق أوتوماتيكي لجميع أنواع الأغطية: لولبي، كبس، مضخة. التحكم في عزم الدوران للإغلاق المثالي.'
    },
    image: 'https://images.unsplash.com/photo-1764745021344-317b80f09e40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwcGFja2FnaW5nJTIwbWFjaGluZXxlbnwxfHx8fDE3Njg2ODYxNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Vitesse: Jusqu\'à 2 500 bouchons/heure',
        'Types: Vissage, pression, pompe',
        'Contrôle de couple réglable',
        'Changement format rapide'
      ],
      en: [
        'Speed: Up to 2,500 caps/hour',
        'Types: Screw, snap, pump',
        'Adjustable torque control',
        'Quick format changeover'
      ],
      ar: [
        'السرعة: حتى 2500 غطاء/ساعة',
        'الأنواع: لولبي، كبس، مضخة',
        'التحكم في عزم الدوران القابل للتعديل',
        'تغيير سريع للشكل'
      ]
    },
    applications: {
      fr: ['Cosmétique', 'Pharmaceutique', 'Agroalimentaire', 'Chimie'],
      en: ['Cosmetics', 'Pharmaceutical', 'Agro-food', 'Chemicals'],
      ar: ['مستحضرات التجميل', 'الأدوية', 'الصناعات الغذائية', 'المواد الكيميائية']
    },
    features: {
      fr: ['Multi-types bouchons', 'Contrôle couple électronique', 'Détection présence bouchon', 'Système anti-rotation bouteille'],
      en: ['Multi-cap types', 'Electronic torque control', 'Cap presence detection', 'Anti-rotation bottle system'],
      ar: ['أنواع متعددة من الأغطية', 'التحكم الإلكتروني في عزم الدوران', 'كشف وجود الغطاء', 'نظام مضاد لدوران الزجاجة']
    },
    featured: true
  },
  {
    id: 'cme-520s',
    model: 'CME 520S',
    category: 'bouchonneuses',
    subcategory: 'Sertissage',
    name: {
      fr: 'Sertisseuse Automatique',
      en: 'Automatic Crimping Machine',
      ar: 'آلة التثبيت الأوتوماتيكية'
    },
    description: {
      fr: 'Machine de sertissage pour capsules aluminium et bouchons à sertir. Parfaite pour produits pharmaceutiques et cosmétiques haut de gamme.',
      en: 'Crimping machine for aluminum capsules and crimp caps. Perfect for pharmaceutical and high-end cosmetic products.',
      ar: 'آلة تثبيت للكبسولات الألومنيوم وأغطية التثبيت. مثالية للمنتجات الصيدلانية ومستحضرات التجميل الراقية.'
    },
    image: 'https://images.unsplash.com/photo-1733683296842-c5c32fe36a50?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwbWFjaGluZXJ5JTIwbWV0YWx8ZW58MXx8fHwxNzY4NjQ4MjMwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Vitesse: 1 500-2 000 sertissages/heure',
        'Capsules alu ou plastique',
        'Pression ajustable',
        'Vérification sertissage'
      ],
      en: [
        'Speed: 1,500-2,000 crimps/hour',
        'Aluminum or plastic capsules',
        'Adjustable pressure',
        'Crimp verification'
      ],
      ar: [
        'السرعة: 1500-2000 تثبيت/ساعة',
        'كبسولات ألومنيوم أو بلاستيك',
        'ضغط قابل للتعديل',
        'التحقق من التثبيت'
      ]
    },
    applications: {
      fr: ['Pharmaceutique', 'Parfumerie', 'Vins et spiritueux', 'Cosmétique premium'],
      en: ['Pharmaceutical', 'Perfumery', 'Wines and spirits', 'Premium cosmetics'],
      ar: ['الأدوية', 'العطور', 'النبيذ والمشروبات الروحية', 'مستحضرات التجميل الفاخرة']
    },
    features: {
      fr: ['Sertissage uniforme', 'Ajustement précis', 'Finition esthétique', 'Compatible multi-formats'],
      en: ['Uniform crimping', 'Precise adjustment', 'Aesthetic finish', 'Multi-format compatible'],
      ar: ['تثبيت موحد', 'ضبط دقيق', 'لمسة نهائية جمالية', 'متوافق مع أشكال متعددة']
    }
  },
  {
    id: 'cme-530i',
    model: 'CME 530I',
    category: 'bouchonneuses',
    subcategory: 'Induction',
    name: {
      fr: 'Scelleuse par Induction',
      en: 'Induction Sealing Machine',
      ar: 'آلة الختم بالحث'
    },
    description: {
      fr: 'Système de scellage par induction pour opercules aluminium. Garantit l\'inviolabilité et la conservation optimale des produits.',
      en: 'Induction sealing system for aluminum seals. Guarantees tamper-evidence and optimal product preservation.',
      ar: 'نظام ختم بالحث لأختام الألومنيوم. يضمن عدم العبث والحفاظ الأمثل على المنتجات.'
    },
    image: 'https://images.unsplash.com/photo-1764745021344-317b80f09e40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwcGFja2FnaW5nJTIwbWFjaGluZXxlbnwxfHx8fDE3Njg2ODYxNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Vitesse: Jusqu\'à 3 000 unités/heure',
        'Puissance réglable 500-3000W',
        'Convoyeur intégré',
        'Sans contact produit'
      ],
      en: [
        'Speed: Up to 3,000 units/hour',
        'Adjustable power 500-3000W',
        'Integrated conveyor',
        'Non-contact with product'
      ],
      ar: [
        'السرعة: حتى 3000 وحدة/ساعة',
        'قوة قابلة للتعديل 500-3000 واط',
        'ناقل متكامل',
        'بدون اتصال مع المنتج'
      ]
    },
    applications: {
      fr: ['Pharmaceutique', 'Agroalimentaire', 'Compléments', 'Produits sensibles'],
      en: ['Pharmaceutical', 'Agro-food', 'Supplements', 'Sensitive products'],
      ar: ['الأدوية', 'الصناعات الغذائية', 'المكملات', 'المنتجات الحساسة']
    },
    features: {
      fr: ['Scellage hermétique', 'Inviolabilité garantie', 'Réglage automatique', 'Économie d\'énergie'],
      en: ['Hermetic sealing', 'Guaranteed tamper-evidence', 'Automatic adjustment', 'Energy saving'],
      ar: ['ختم محكم', 'ضمان عدم العبث', 'ضبط تلقائي', 'توفير الطاقة']
    }
  },

  // LIGNES COMPLÈTES - Complete Lines
  {
    id: 'cme-700l',
    model: 'CME 700L',
    category: 'lignes-completes',
    name: {
      fr: 'Ligne de Conditionnement Complète Liquides',
      en: 'Complete Liquid Packaging Line',
      ar: 'خط التعبئة الكامل للسوائل'
    },
    description: {
      fr: 'Ligne complète intégrée pour liquides: remplissage, bouchonnage, étiquetage et conditionnement. Solution turnkey pour production automatisée.',
      en: 'Complete integrated line for liquids: filling, capping, labeling and packaging. Turnkey solution for automated production.',
      ar: 'خط متكامل كامل للسوائل: التعبئة والإغلاق ووضع الملصقات والتغليف. حل جاهز للإنتاج الآلي.'
    },
    image: 'https://images.unsplash.com/photo-1739863306113-2629b0ed2a6b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWN0b3J5JTIwcHJvZHVjdGlvbiUyMGxpbmV8ZW58MXx8fHwxNzY4NjYyMjk2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Production: 2 000-3 000 unités/heure',
        'Remplissage + Bouchonnage + Étiquetage',
        'Contrôle qualité intégré',
        'Supervision centralisée'
      ],
      en: [
        'Production: 2,000-3,000 units/hour',
        'Filling + Capping + Labeling',
        'Integrated quality control',
        'Centralized supervision'
      ],
      ar: [
        'الإنتاج: 2000-3000 وحدة/ساعة',
        'التعبئة + الإغلاق + وضع الملصقات',
        'مراقبة الجودة المتكاملة',
        'إشراف مركزي'
      ]
    },
    applications: {
      fr: ['Cosmétique', 'Pharmaceutique liquide', 'Brasserie', 'Chimie'],
      en: ['Cosmetics', 'Liquid pharmaceutical', 'Beverages', 'Chemicals'],
      ar: ['مستحضرات التجميل', 'الأدوية السائلة', 'المشروبات', 'المواد الكيميائية']
    },
    features: {
      fr: ['Ligne entièrement automatique', 'Synchronisation machines', 'Interface centralisée', 'Production optimisée'],
      en: ['Fully automatic line', 'Machine synchronization', 'Centralized interface', 'Optimized production'],
      ar: ['خط أوتوماتيكي بالكامل', 'مزامنة الآلات', 'واجهة مركزية', 'إنتاج محسن']
    },
    featured: true
  },
  {
    id: 'cme-710c',
    model: 'CME 710C',
    category: 'lignes-completes',
    name: {
      fr: 'Ligne Complète Cosmétique',
      en: 'Complete Cosmetic Line',
      ar: 'خط مستحضرات التجميل الكامل'
    },
    description: {
      fr: 'Ligne spécialisée pour cosmétiques: remplissage crèmes/liquides, bouchonnage, étiquetage multi-faces, emballage. Conçue pour environnement salle blanche.',
      en: 'Specialized line for cosmetics: cream/liquid filling, capping, multi-sided labeling, packaging. Designed for clean room environment.',
      ar: 'خط متخصص لمستحضرات التجميل: تعبئة الكريمات/السوائل، الإغلاق، وضع ملصقات متعددة الجوانب، التغليف. مصمم لبيئة الغرفة النظيفة.'
    },
    image: 'https://images.unsplash.com/photo-1593775832814-3a7829380c7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3NtZXRpY3MlMjBwcm9kdWN0aW9uJTIwZmFjdG9yeXxlbnwxfHx8fDE3Njg2ODYxNDd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Cadence: 1 500-2 500 unités/heure',
        'Multi-viscosité',
        'Étiquetage 360° + top',
        'Normes ISO salle blanche'
      ],
      en: [
        'Rate: 1,500-2,500 units/hour',
        'Multi-viscosity',
        '360° + top labeling',
        'ISO clean room standards'
      ],
      ar: [
        'المعدل: 1500-2500 وحدة/ساعة',
        'لزوجة متعددة',
        'وضع ملصقات 360 درجة + علوي',
        'معايير ISO للغرفة النظيفة'
      ]
    },
    applications: {
      fr: ['Cosmétique premium', 'Soins de la peau', 'Parfumerie', 'Produits de beauté'],
      en: ['Premium cosmetics', 'Skincare', 'Perfumery', 'Beauty products'],
      ar: ['مستحضرات التجميل الفاخرة', 'العناية بالبشرة', 'العطور', 'منتجات التجميل']
    },
    features: {
      fr: ['Environnement contrôlé', 'Finition premium', 'Traçabilité lot', 'Flexibilité formats'],
      en: ['Controlled environment', 'Premium finish', 'Batch traceability', 'Format flexibility'],
      ar: ['بيئة محكومة', 'لمسة نهائية فاخرة', 'تتبع الدفعة', 'مرونة الأشكال']
    }
  },
  {
    id: 'cme-720p',
    model: 'CME 720P',
    category: 'lignes-completes',
    name: {
      fr: 'Ligne Pharmaceutique Complète',
      en: 'Complete Pharmaceutical Line',
      ar: 'خط الأدوية الكامل'
    },
    description: {
      fr: 'Ligne conforme GMP pour pharmaceutique: remplissage stérile, bouchonnage/sertissage, scellage induction, étiquetage traçable, sérialisation.',
      en: 'GMP-compliant line for pharmaceuticals: sterile filling, capping/crimping, induction sealing, traceable labeling, serialization.',
      ar: 'خط متوافق مع GMP للأدوية: تعبئة معقمة، إغلاق/تثبيت، ختم بالحث، وضع ملصقات قابلة للتتبع، ترقيم متسلسل.'
    },
    image: 'https://images.unsplash.com/photo-1740362381367-09cb98b4e1c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaGFybWFjZXV0aWNhbCUyMG1hbnVmYWN0dXJpbmclMjBlcXVpcG1lbnR8ZW58MXx8fHwxNzY4Njg2MTQ3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Production: 1 200-2 000 unités/heure',
        'Conforme GMP/FDA',
        'Sérialisation intégrée',
        'Validation IQ/OQ/PQ'
      ],
      en: [
        'Production: 1,200-2,000 units/hour',
        'GMP/FDA compliant',
        'Integrated serialization',
        'IQ/OQ/PQ validation'
      ],
      ar: [
        'الإنتاج: 1200-2000 وحدة/ساعة',
        'متوافق مع GMP/FDA',
        'ترقيم متسلسل متكامل',
        'التحقق IQ/OQ/PQ'
      ]
    },
    applications: {
      fr: ['Médicaments liquides', 'Sirops', 'Solutions injectables', 'Antibiotiques'],
      en: ['Liquid medicines', 'Syrups', 'Injectable solutions', 'Antibiotics'],
      ar: ['الأدوية السائلة', 'الشراب', 'المحاليل القابلة للحقن', 'المضادات الحيوية']
    },
    features: {
      fr: ['Conformité réglementaire', 'Traçabilité totale', 'Documentation complète', 'Support validation'],
      en: ['Regulatory compliance', 'Total traceability', 'Complete documentation', 'Validation support'],
      ar: ['الامتثال التنظيمي', 'تتبع كامل', 'وثائق كاملة', 'دعم التحقق']
    }
  },
  {
    id: 'cme-730a',
    model: 'CME 730A',
    category: 'lignes-completes',
    name: {
      fr: 'Ligne Agroalimentaire',
      en: 'Agro-food Line',
      ar: 'خط الصناعات الغذائية'
    },
    description: {
      fr: 'Ligne complète pour produits alimentaires: remplissage, capsulage, étiquetage, datage, mise en cartons. Construction alimentaire inox 316L.',
      en: 'Complete line for food products: filling, capping, labeling, dating, cartoning. Food-grade 316L stainless steel construction.',
      ar: 'خط كامل للمنتجات الغذائية: التعبئة، الإغلاق، وضع الملصقات، التأريخ، التعبئة في الكراتين. بناء من الفولاذ المقاوم للصدأ 316L درجة غذائية.'
    },
    image: 'https://images.unsplash.com/photo-1764160454561-0f092320e9e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcHJvY2Vzc2luZyUyMG1hY2hpbmVyeXxlbnwxfHx8fDE3Njg2ODYxNDd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    specs: {
      fr: [
        'Débit: 2 500-4 000 unités/heure',
        'Construction sanitaire',
        'Nettoyage CIP/NEP',
        'Datage jet d\'encre'
      ],
      en: [
        'Flow: 2,500-4,000 units/hour',
        'Sanitary construction',
        'CIP/NEP cleaning',
        'Inkjet dating'
      ],
      ar: [
        'التدفق: 2500-4000 وحدة/ساعة',
        'بناء صحي',
        'تنظيف CIP/NEP',
        'تأريخ نفث الحبر'
      ]
    },
    applications: {
      fr: ['Sauces', 'Huiles', 'Jus de fruits', 'Produits laitiers'],
      en: ['Sauces', 'Oils', 'Fruit juices', 'Dairy products'],
      ar: ['الصلصات', 'الزيوت', 'عصائر الفواكه', 'منتجات الألبان']
    },
    features: {
      fr: ['Hygiène alimentaire', 'Nettoyage automatique', 'Traçabilité lot', 'Contrôle température'],
      en: ['Food hygiene', 'Automatic cleaning', 'Batch traceability', 'Temperature control'],
      ar: ['النظافة الغذائية', 'تنظيف تلقائي', 'تتبع الدفعة', 'التحكم في درجة الحرارة']
    }
  }
];

export const categories = [
  { id: 'all', name: { fr: 'Toutes', en: 'All', ar: 'الكل' } },
  { id: 'etiqueteuses', name: { fr: 'Étiqueteuses', en: 'Labeling Machines', ar: 'آلات اللصق' } },
  { id: 'remplisseuses', name: { fr: 'Remplisseuses', en: 'Filling Machines', ar: 'آلات التعبئة' } },
  { id: 'bouchonneuses', name: { fr: 'Bouchonneuses & Sertisseuses', en: 'Capping & Sealing', ar: 'آلات الإغلاق والختم' } },
  { id: 'lignes-completes', name: { fr: 'Lignes Complètes', en: 'Complete Lines', ar: 'خطوط كاملة' } }
];

export const getCategoryMachines = (category: string) => {
  if (category === 'all') return machines;
  return machines.filter(m => m.category === category);
};

export const getFeaturedMachines = () => {
  return machines.filter(m => m.featured);
};

export const getMachineById = (id: string) => {
  return machines.find(m => m.id === id);
};
