import { Facebook, Linkedin, Mail, Phone, MapPin, Instagram, Twitter } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export function Footer() {
  const { t, language } = useLanguage();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer className="bg-gradient-to-br from-[#0A2A4A] via-[#0d3a5f] to-[#0A2A4A] text-white relative overflow-hidden">
      {/* Decorative Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }}></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-14 h-14 bg-gradient-to-br from-[#F46524] to-orange-600 rounded-2xl flex items-center justify-center shadow-2xl">
                <span className="text-white font-bold text-2xl">Z</span>
              </div>
              <div>
                <div className="font-bold text-2xl">Zayani C.M.E</div>
                <div className="text-sm text-gray-400 font-medium">{t.footer.tagline}</div>
              </div>
            </div>
            <p className="text-gray-400 leading-relaxed mb-6">
              {t.footer.description}
            </p>
            
            {/* Social Media */}
            <div className="flex gap-3">
              {[
                { icon: Facebook, label: 'Facebook' },
                { icon: Linkedin, label: 'LinkedIn' },
                { icon: Instagram, label: 'Instagram' },
                { icon: Twitter, label: 'Twitter' }
              ].map((social, idx) => (
                <a
                  key={idx}
                  href="#"
                  className="bg-white/5 hover:bg-gradient-to-br hover:from-[#F46524] hover:to-orange-600 w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-300 hover:scale-110 hover:-translate-y-1 border border-white/10"
                  aria-label={social.label}
                >
                  <social.icon size={20} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-xl mb-6 text-white">{t.footer.quickLinks}</h4>
            <ul className="space-y-3">
              {[
                { name: t.nav.home, id: 'home' },
                { name: t.nav.about, id: 'about' },
                { name: t.nav.machines, id: 'products' },
                { name: t.nav.sectors, id: 'industries' },
                { name: t.nav.contact, id: 'contact' }
              ].map((link, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => scrollToSection(link.id)}
                    className="text-gray-400 hover:text-[#F46524] transition-colors duration-200 hover:translate-x-1 inline-block"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Products */}
          <div>
            <h4 className="font-bold text-xl mb-6 text-white">{t.footer.products}</h4>
            <ul className="space-y-3 text-gray-400">
              <li className="hover:text-[#F46524] transition-colors cursor-pointer">{t.footer.productList.labeling}</li>
              <li className="hover:text-[#F46524] transition-colors cursor-pointer">{t.footer.productList.filling}</li>
              <li className="hover:text-[#F46524] transition-colors cursor-pointer">{t.footer.productList.capping}</li>
              <li className="hover:text-[#F46524] transition-colors cursor-pointer">{t.footer.productList.complete}</li>
              <li className="hover:text-[#F46524] transition-colors cursor-pointer">{t.footer.productList.custom}</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-bold text-xl mb-6 text-white">{t.footer.contactUs}</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 group">
                <div className="bg-gradient-to-br from-[#F46524] to-orange-600 w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <MapPin size={18} />
                </div>
                <span className="text-gray-400 leading-relaxed">
                  Zone Industrielle<br />
                  Nabeul 8000, Tunisia
                </span>
              </li>
              <li className="flex items-center gap-3 group">
                <div className="bg-gradient-to-br from-[#F46524] to-orange-600 w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <Phone size={18} />
                </div>
                <span className="text-gray-400">+216 72 123 456</span>
              </li>
              <li className="flex items-center gap-3 group">
                <div className="bg-gradient-to-br from-[#F46524] to-orange-600 w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <Mail size={18} />
                </div>
                <span className="text-gray-400">info@zayani-cme.tn</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-center md:text-left">
              {t.footer.copyright}
            </p>
            <div className="flex flex-wrap justify-center gap-6">
              <a href="#" className="text-gray-400 hover:text-[#F46524] transition-colors">
                {t.footer.legal.privacy}
              </a>
              <a href="#" className="text-gray-400 hover:text-[#F46524] transition-colors">
                {t.footer.legal.terms}
              </a>
              <a href="#" className="text-gray-400 hover:text-[#F46524] transition-colors">
                {t.footer.legal.cookies}
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
