import { motion } from 'motion/react';
import { Tag, Droplet, Lock, Package, ArrowRight } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';

export function Products() {
  const { t, language } = useLanguage();

  const products = [
    {
      icon: Tag,
      title: t.products.categories.labeling,
      subtitle: t.products.categories.labelingSub,
      description: t.products.categories.labelingDesc,
      features: t.products.features.labeling,
      image: 'https://images.unsplash.com/photo-1522753071498-f3137a65aee3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYWJlbGluZyUyMG1hY2hpbmUlMjBmYWN0b3J5fGVufDF8fHx8MTc2ODY4NjE0NXww&ixlib=rb-4.1.0&q=80&w=1080',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Droplet,
      title: t.products.categories.filling,
      subtitle: t.products.categories.fillingSub,
      description: t.products.categories.fillingDesc,
      features: t.products.features.filling,
      image: 'https://images.unsplash.com/photo-1701448149957-b96dbd1926ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaWxsaW5nJTIwbWFjaGluZSUyMHByb2R1Y3Rpb258ZW58MXx8fHwxNzY4Njg2MTQ3fDA&ixlib=rb-4.1.0&q=80&w=1080',
      gradient: 'from-[#F46524] to-orange-600'
    },
    {
      icon: Lock,
      title: t.products.categories.capping,
      subtitle: t.products.categories.cappingSub,
      description: t.products.categories.cappingDesc,
      features: t.products.features.capping,
      image: 'https://images.unsplash.com/photo-1764745021344-317b80f09e40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwcGFja2FnaW5nJTIwbWFjaGluZXxlbnwxfHx8fDE3Njg2ODYxNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: Package,
      title: t.products.categories.complete,
      subtitle: t.products.categories.completeSub,
      description: t.products.categories.completeDesc,
      features: t.products.features.complete,
      image: 'https://images.unsplash.com/photo-1739863306113-2629b0ed2a6b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWN0b3J5JTIwcHJvZHVjdGlvbiUyMGxpbmV8ZW58MXx8fHwxNzY4NjYyMjk2fDA&ixlib=rb-4.1.0&q=80&w=1080',
      gradient: 'from-purple-500 to-pink-500'
    }
  ];

  return (
    <section id="products" className="py-32 bg-[#0A2A4A] relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }}></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center max-w-4xl mx-auto mb-20"
        >
          <div className="inline-block bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-6 py-2 rounded-full font-semibold text-sm mb-6">
            {t.products.badge}
          </div>
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-8 leading-tight">
            {t.products.title}<br />
            <span className="bg-gradient-to-r from-[#F46524] to-orange-600 bg-clip-text text-transparent">
              {t.products.titleAccent}
            </span>
          </h2>
          <p className="text-xl md:text-2xl text-gray-300 font-light">
            {t.products.description}
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {products.map((product, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="group relative"
            >
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl overflow-hidden hover:bg-white/10 transition-all duration-500 hover:-translate-y-2">
                {/* Image */}
                <div className="relative h-72 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${product.gradient} opacity-40 group-hover:opacity-50 transition-opacity`}></div>
                  
                  {/* Icon Badge */}
                  <div className="absolute top-6 right-6">
                    <div className={`bg-gradient-to-br ${product.gradient} w-16 h-16 rounded-2xl flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:rotate-12 transition-all duration-500`}>
                      <product.icon className="text-white" size={32} />
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-8">
                  <div className="text-xs text-[#F46524] font-semibold uppercase tracking-wider mb-2">
                    {product.subtitle}
                  </div>
                  <h3 className="text-3xl font-bold text-white mb-4">{product.title}</h3>
                  <p className="text-gray-300 mb-6 leading-relaxed">{product.description}</p>

                  {/* Features */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {product.features.map((feature, idx) => (
                      <span
                        key={idx}
                        className="bg-white/10 backdrop-blur-sm border border-white/20 text-white text-sm px-4 py-2 rounded-full"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>

                  <Button
                    variant="ghost"
                    className="text-[#F46524] hover:text-orange-400 group/btn p-0 hover:bg-transparent"
                  >
                    {t.products.cta}
                    <ArrowRight className="ml-2 group-hover/btn:translate-x-2 transition-transform" size={18} />
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
