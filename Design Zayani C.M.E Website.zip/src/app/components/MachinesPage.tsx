import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Filter } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { machines, categories, getCategoryMachines, Machine } from '@/data/machines';
import { QuoteModal } from '@/app/components/QuoteModal';

export function MachinesPage() {
  const { t, language } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedMachine, setSelectedMachine] = useState<Machine | null>(null);
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);

  const filteredMachines = getCategoryMachines(selectedCategory);

  const openQuoteModal = (machine: Machine) => {
    setSelectedMachine(machine);
    setIsQuoteModalOpen(true);
  };

  return (
    <section id="machines-page" className="py-32 bg-gradient-to-b from-white via-gray-50 to-white relative overflow-hidden min-h-screen">
      {/* Decorative Elements */}
      <div className="absolute top-20 right-0 w-96 h-96 bg-[#F46524]/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-0 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-4xl mx-auto mb-16"
        >
          <div className="inline-block bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-6 py-2 rounded-full font-semibold text-sm mb-6">
            {language === 'fr' ? 'NOS MACHINES' : language === 'en' ? 'OUR MACHINES' : 'آلاتنا'}
          </div>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-[#0A2A4A] mb-8 leading-tight">
            {language === 'fr' ? 'Catalogue' : language === 'en' ? 'Catalog' : 'الكتالوج'}
            <br />
            <span className="bg-gradient-to-r from-[#F46524] to-orange-600 bg-clip-text text-transparent">
              {language === 'fr' ? 'Complet' : language === 'en' ? 'Complete' : 'الكامل'}
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-[#6B6B6B] font-light">
            {language === 'fr' 
              ? 'Découvrez notre gamme complète de machines industrielles de conditionnement' 
              : language === 'en' 
              ? 'Discover our complete range of industrial packaging machinery' 
              : 'اكتشف مجموعتنا الكاملة من آلات التعبئة والتغليف الصناعية'
            }
          </p>
        </motion.div>

        {/* Category Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap items-center justify-center gap-3 mb-16"
        >
          <div className="flex items-center gap-2 text-[#6B6B6B] px-4 py-2">
            <Filter size={20} />
            <span className="font-semibold">
              {language === 'fr' ? 'Filtrer par catégorie:' : language === 'en' ? 'Filter by category:' : 'تصفية حسب الفئة:'}
            </span>
          </div>
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-[#F46524] to-orange-600 text-white shadow-lg scale-105'
                  : 'bg-white text-[#0A2A4A] border-2 border-gray-200 hover:border-[#F46524] hover:text-[#F46524]'
              }`}
            >
              {category.name[language]}
            </button>
          ))}
        </motion.div>

        {/* Results Count */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mb-8"
        >
          <p className="text-[#6B6B6B]">
            <span className="font-bold text-[#F46524] text-xl">{filteredMachines.length}</span>{' '}
            {language === 'fr' 
              ? filteredMachines.length > 1 ? 'machines disponibles' : 'machine disponible'
              : language === 'en' 
              ? filteredMachines.length > 1 ? 'machines available' : 'machine available'
              : filteredMachines.length > 1 ? 'آلات متاحة' : 'آلة متاحة'
            }
          </p>
        </motion.div>

        {/* Machines Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredMachines.map((machine, index) => (
            <motion.div
              key={machine.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group bg-white rounded-3xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-gray-100"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={machine.image}
                  alt={machine.name[language]}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A2A4A]/80 to-transparent"></div>
                
                {/* Model Badge */}
                <div className="absolute top-4 right-4">
                  <div className="bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-4 py-2 rounded-xl font-bold shadow-2xl">
                    {machine.model}
                  </div>
                </div>

                {/* Category Badge */}
                <div className="absolute bottom-4 left-4">
                  <div className="bg-white/90 backdrop-blur-sm text-[#0A2A4A] px-4 py-1 rounded-full text-sm font-semibold">
                    {machine.subcategory || categories.find(c => c.id === machine.category)?.name[language]}
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-2xl font-bold text-[#0A2A4A] mb-3">
                  {machine.name[language]}
                </h3>
                <p className="text-[#6B6B6B] mb-4 line-clamp-2">
                  {machine.description[language]}
                </p>

                {/* Features */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {machine.features[language].slice(0, 3).map((feature, idx) => (
                    <span
                      key={idx}
                      className="bg-gray-100 text-[#0A2A4A] text-xs px-3 py-1 rounded-full"
                    >
                      {feature}
                    </span>
                  ))}
                </div>

                {/* CTA Button */}
                <Button
                  onClick={() => openQuoteModal(machine)}
                  className="w-full bg-gradient-to-r from-[#F46524] to-orange-600 hover:from-[#d65620] hover:to-[#F46524] text-white rounded-xl py-6 group/btn"
                >
                  {language === 'fr' ? 'Demander un devis' : language === 'en' ? 'Request Quote' : 'طلب عرض'}
                  <ArrowRight className="ml-2 group-hover/btn:translate-x-1 transition-transform" size={18} />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* No Results */}
        {filteredMachines.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <p className="text-2xl text-[#6B6B6B]">
              {language === 'fr' 
                ? 'Aucune machine trouvée dans cette catégorie' 
                : language === 'en' 
                ? 'No machines found in this category' 
                : 'لم يتم العثور على آلات في هذه الفئة'
              }
            </p>
          </motion.div>
        )}
      </div>

      {/* Quote Modal */}
      <QuoteModal
        isOpen={isQuoteModalOpen}
        onClose={() => setIsQuoteModalOpen(false)}
        machine={selectedMachine}
      />
    </section>
  );
}
