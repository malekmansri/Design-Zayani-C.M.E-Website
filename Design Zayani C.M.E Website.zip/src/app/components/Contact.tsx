import { motion } from 'motion/react';
import { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle, Clock } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Textarea } from '@/app/components/ui/textarea';
import { useLanguage } from '@/contexts/LanguageContext';

export function Contact() {
  const { t, language } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: '', company: '', email: '', phone: '', message: '' });
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: t.contact.info.visit,
      content: 'Zone Industrielle\nNabeul 8000, Tunisia',
      gradient: 'from-blue-500 to-cyan-600'
    },
    {
      icon: Phone,
      title: t.contact.info.call,
      content: '+216 72 123 456\n+216 98 765 432',
      gradient: 'from-[#F46524] to-orange-600'
    },
    {
      icon: Mail,
      title: t.contact.info.email,
      content: 'info@zayani-cme.tn\ncontact@zayani-cme.tn',
      gradient: 'from-green-500 to-emerald-600'
    }
  ];

  return (
    <section id="contact" className="py-32 bg-gradient-to-b from-white via-gray-50 to-white relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-20 -right-20 w-96 h-96 bg-gradient-to-br from-[#F46524]/10 to-orange-600/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 -left-20 w-96 h-96 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center max-w-4xl mx-auto mb-20"
        >
          <div className="inline-block bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-6 py-2 rounded-full font-semibold text-sm mb-6">
            {t.contact.badge}
          </div>
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold text-[#0A2A4A] mb-8 leading-tight">
            {t.contact.title}<br />
            <span className="bg-gradient-to-r from-[#F46524] to-orange-600 bg-clip-text text-transparent">
              {t.contact.titleAccent}
            </span>
          </h2>
          <p className="text-xl md:text-2xl text-[#6B6B6B] font-light">
            {t.contact.description}
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-8 max-w-7xl mx-auto">
          {/* Contact Cards - Left Side */}
          <div className="lg:col-span-2 space-y-6">
            {contactInfo.map((info, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="group"
              >
                <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-1 border border-gray-100 relative overflow-hidden">
                  <div className={`absolute inset-0 bg-gradient-to-br ${info.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`}></div>
                  <div className="flex items-start gap-4 relative z-10">
                    <div className={`bg-gradient-to-br ${info.gradient} w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 shadow-xl`}>
                      <info.icon className="text-white" size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-[#0A2A4A] mb-2 text-lg">{info.title}</h4>
                      <p className="text-[#6B6B6B] whitespace-pre-line leading-relaxed">
                        {info.content}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Business Hours */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              viewport={{ once: true }}
            >
              <div className="bg-gradient-to-br from-[#0A2A4A] to-[#1a4a6f] rounded-3xl p-8 text-white shadow-2xl">
                <div className="flex items-center gap-3 mb-6">
                  <div className="bg-white/10 backdrop-blur-sm w-14 h-14 rounded-2xl flex items-center justify-center">
                    <Clock className="text-[#F46524]" size={24} />
                  </div>
                  <h4 className="font-bold text-xl">{t.contact.hours.title}</h4>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center pb-3 border-b border-white/10">
                    <span className="text-gray-300">{t.contact.hours.weekdays}</span>
                    <span className="font-semibold">8:00 AM - 6:00 PM</span>
                  </div>
                  <div className="flex justify-between items-center pb-3 border-b border-white/10">
                    <span className="text-gray-300">{t.contact.hours.saturday}</span>
                    <span className="font-semibold">9:00 AM - 2:00 PM</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">{t.contact.hours.sunday}</span>
                    <span className="font-semibold">{t.contact.hours.closed}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Contact Form - Right Side */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="lg:col-span-3"
          >
            <div className="bg-white rounded-3xl shadow-2xl p-10 border border-gray-100">
              {!submitted ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-bold text-[#0A2A4A] mb-3">
                        {t.contact.form.name} {t.contact.form.required}
                      </label>
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full border-2 border-gray-200 focus:border-[#F46524] focus:ring-2 focus:ring-[#F46524]/20 rounded-2xl px-5 py-6 text-base"
                      />
                    </div>

                    <div>
                      <label htmlFor="company" className="block text-sm font-bold text-[#0A2A4A] mb-3">
                        {t.contact.form.company}
                      </label>
                      <Input
                        id="company"
                        name="company"
                        type="text"
                        value={formData.company}
                        onChange={handleChange}
                        className="w-full border-2 border-gray-200 focus:border-[#F46524] focus:ring-2 focus:ring-[#F46524]/20 rounded-2xl px-5 py-6 text-base"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="email" className="block text-sm font-bold text-[#0A2A4A] mb-3">
                        {t.contact.form.email} {t.contact.form.required}
                      </label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full border-2 border-gray-200 focus:border-[#F46524] focus:ring-2 focus:ring-[#F46524]/20 rounded-2xl px-5 py-6 text-base"
                      />
                    </div>

                    <div>
                      <label htmlFor="phone" className="block text-sm font-bold text-[#0A2A4A] mb-3">
                        {t.contact.form.phone}
                      </label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full border-2 border-gray-200 focus:border-[#F46524] focus:ring-2 focus:ring-[#F46524]/20 rounded-2xl px-5 py-6 text-base"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-bold text-[#0A2A4A] mb-3">
                      {t.contact.form.message} {t.contact.form.required}
                    </label>
                    <Textarea
                      id="message"
                      name="message"
                      required
                      value={formData.message}
                      onChange={handleChange}
                      rows={6}
                      className="w-full border-2 border-gray-200 focus:border-[#F46524] focus:ring-2 focus:ring-[#F46524]/20 rounded-2xl px-5 py-4 text-base resize-none"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-[#F46524] to-orange-600 hover:from-[#d65620] hover:to-[#F46524] text-white py-7 text-lg rounded-2xl group shadow-2xl shadow-[#F46524]/30"
                  >
                    {t.contact.form.submit}
                    <Send className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
                  </Button>
                </form>
              ) : (
                <div className="flex flex-col items-center justify-center py-16">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.5, type: 'spring' }}
                    className="bg-gradient-to-br from-green-500 to-emerald-600 w-24 h-24 rounded-full flex items-center justify-center mb-6 shadow-2xl"
                  >
                    <CheckCircle className="text-white" size={48} />
                  </motion.div>
                  <h3 className="text-3xl font-bold text-[#0A2A4A] mb-3">{t.contact.form.success}</h3>
                  <p className="text-lg text-[#6B6B6B] text-center max-w-md">
                    {t.contact.form.successMsg}
                  </p>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
