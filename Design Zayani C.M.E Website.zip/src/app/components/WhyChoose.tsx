import { motion } from 'motion/react';
import { Shield, Wrench, Sliders, HeadphonesIcon, Award, TrendingUp, Users, Zap } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export function WhyChoose() {
  const { t } = useLanguage();

  const benefits = [
    {
      icon: Shield,
      title: t.whyChoose.benefits.durable,
      description: t.whyChoose.benefits.durableDesc,
      gradient: 'from-blue-500 to-cyan-600'
    },
    {
      icon: Wrench,
      title: t.whyChoose.benefits.simple,
      description: t.whyChoose.benefits.simpleDesc,
      gradient: 'from-[#F46524] to-orange-600'
    },
    {
      icon: Sliders,
      title: t.whyChoose.benefits.custom,
      description: t.whyChoose.benefits.customDesc,
      gradient: 'from-green-500 to-emerald-600'
    },
    {
      icon: HeadphonesIcon,
      title: t.whyChoose.benefits.support,
      description: t.whyChoose.benefits.supportDesc,
      gradient: 'from-purple-500 to-pink-600'
    }
  ];

  const stats = [
    { icon: Award, value: '17+', label: t.whyChoose.stats.years, gradient: 'from-blue-500 to-cyan-600' },
    { icon: TrendingUp, value: '500+', label: t.whyChoose.stats.installed, gradient: 'from-[#F46524] to-orange-600' },
    { icon: Users, value: '98%', label: t.whyChoose.stats.satisfaction, gradient: 'from-green-500 to-emerald-600' },
    { icon: Zap, value: '24/7', label: t.whyChoose.stats.available, gradient: 'from-purple-500 to-pink-600' }
  ];

  return (
    <section id="why-choose" className="py-32 bg-gradient-to-b from-white via-gray-50 to-white relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-20 right-0 w-96 h-96 bg-gradient-to-br from-[#F46524]/10 to-orange-600/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-0 w-96 h-96 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center max-w-4xl mx-auto mb-20"
        >
          <div className="inline-block bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-6 py-2 rounded-full font-semibold text-sm mb-6">
            {t.whyChoose.badge}
          </div>
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold text-[#0A2A4A] mb-8 leading-tight">
            {t.whyChoose.title}<br />
            <span className="bg-gradient-to-r from-[#F46524] to-orange-600 bg-clip-text text-transparent">
              {t.whyChoose.titleAccent}
            </span>
          </h2>
          <p className="text-xl md:text-2xl text-[#6B6B6B] font-light">
            {t.whyChoose.description}
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-20">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="group"
            >
              <div className="bg-white rounded-3xl p-10 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 h-full border border-gray-100 relative overflow-hidden">
                {/* Gradient Background on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${benefit.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`}></div>
                
                <div className="flex items-start gap-6 relative z-10">
                  <div className={`bg-gradient-to-br ${benefit.gradient} w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 shadow-xl`}>
                    <benefit.icon className="text-white" size={32} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-[#0A2A4A] mb-4">{benefit.title}</h3>
                    <p className="text-[#6B6B6B] text-lg leading-relaxed">{benefit.description}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-[#0A2A4A] via-[#0d3a5f] to-[#1a4a6f] rounded-3xl p-12 md:p-16 relative overflow-hidden"
        >
          {/* Decorative Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
              backgroundSize: '40px 40px'
            }}></div>
          </div>

          <div className="relative z-10">
            <div className="text-center mb-12">
              <h3 className="text-3xl md:text-4xl font-bold text-white mb-4">
                {t.whyChoose.stats.title}
              </h3>
              <p className="text-gray-300 text-lg">
                {t.whyChoose.stats.subtitle}
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="text-center group"
                >
                  <div className={`bg-gradient-to-br ${stat.gradient} w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 shadow-2xl`}>
                    <stat.icon className="text-white" size={32} />
                  </div>
                  <div className={`text-5xl md:text-6xl font-bold bg-gradient-to-r ${stat.gradient} bg-clip-text text-transparent mb-2`}>
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-300">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
