import { motion } from 'motion/react';
import { Factory, Award, Globe, Users } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export function About() {
  const { t, language } = useLanguage();

  const facts = [
    {
      icon: Factory,
      title: t.about.facts.established,
      description: t.about.facts.establishedDesc,
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Award,
      title: t.about.facts.local,
      description: t.about.facts.localDesc,
      gradient: 'from-[#F46524] to-orange-600'
    },
    {
      icon: Globe,
      title: t.about.facts.export,
      description: t.about.facts.exportDesc,
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: Users,
      title: t.about.facts.team,
      description: t.about.facts.teamDesc,
      gradient: 'from-purple-500 to-pink-500'
    }
  ];

  return (
    <section id="about" className="py-32 bg-gradient-to-b from-white via-gray-50 to-white relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-20 right-0 w-96 h-96 bg-[#F46524]/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-0 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center max-w-4xl mx-auto mb-20"
        >
          <div className="inline-block bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-6 py-2 rounded-full font-semibold text-sm mb-6">
            {t.about.badge}
          </div>
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold text-[#0A2A4A] mb-8 leading-tight">
            {t.about.title}<br />
            <span className="bg-gradient-to-r from-[#F46524] to-orange-600 bg-clip-text text-transparent">
              {t.about.titleAccent}
            </span>
          </h2>
          <p className="text-xl md:text-2xl text-[#6B6B6B] leading-relaxed font-light">
            {t.about.description}
          </p>
        </motion.div>

        {/* Key Facts Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {facts.map((fact, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="group relative"
            >
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl blur-xl -z-10"></div>
              <div className="bg-white border border-gray-100 rounded-3xl p-8 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 h-full relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-gray-50 to-transparent rounded-bl-full opacity-50"></div>
                <div className={`bg-gradient-to-br ${fact.gradient} w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 shadow-lg`}>
                  <fact.icon className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold text-[#0A2A4A] mb-2">{fact.title}</h3>
                <p className="text-[#6B6B6B]">{fact.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Image Gallery */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="grid md:grid-cols-3 gap-6"
        >
          <div className="md:col-span-2 rounded-3xl overflow-hidden shadow-2xl group relative">
            <img
              src="https://images.unsplash.com/photo-1739863306113-2629b0ed2a6b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWN0b3J5JTIwcHJvZHVjdGlvbiUyMGxpbmV8ZW58MXx8fHwxNzY4NjYyMjk2fDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt={t.about.imageCaption1}
              className="w-full h-96 object-cover group-hover:scale-110 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A2A4A]/80 via-transparent to-transparent flex items-end p-8">
              <div className="text-white">
                <h3 className="text-2xl font-bold mb-2">{t.about.imageCaption1}</h3>
                <p className="text-gray-200">{t.about.imageDesc1}</p>
              </div>
            </div>
          </div>
          <div className="rounded-3xl overflow-hidden shadow-2xl group relative">
            <img
              src="https://images.unsplash.com/photo-1733683296842-c5c32fe36a50?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwbWFjaGluZXJ5JTIwbWV0YWx8ZW58MXx8fHwxNzY4NjQ4MjMwfDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt={t.about.imageCaption2}
              className="w-full h-96 object-cover group-hover:scale-110 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A2A4A]/80 via-transparent to-transparent flex items-end p-8">
              <div className="text-white">
                <h3 className="text-xl font-bold mb-2">{t.about.imageCaption2}</h3>
                <p className="text-gray-200 text-sm">{t.about.imageDesc2}</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
