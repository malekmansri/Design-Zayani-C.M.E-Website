import { motion } from 'motion/react';
import { Wheat, Sparkles, Pill, Beaker, Beer, PawPrint, Heart } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export function Industries() {
  const { t, language } = useLanguage();

  const industries = [
    {
      icon: Wheat,
      name: t.industries.list.agrofood,
      description: t.industries.list.agrofoodDesc,
      gradient: 'from-green-500 to-emerald-600',
      image: 'https://images.unsplash.com/photo-1764160454561-0f092320e9e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcHJvY2Vzc2luZyUyMG1hY2hpbmVyeXxlbnwxfHx8fDE3Njg2ODYxNDd8MA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      icon: Sparkles,
      name: t.industries.list.cosmetics,
      description: t.industries.list.cosmeticsDesc,
      gradient: 'from-pink-500 to-rose-600',
      image: 'https://images.unsplash.com/photo-1593775832814-3a7829380c7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3NtZXRpY3MlMjBwcm9kdWN0aW9uJTIwZmFjdG9yeXxlbnwxfHx8fDE3Njg2ODYxNDd8MA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      icon: Pill,
      name: t.industries.list.pharma,
      description: t.industries.list.pharmaDesc,
      gradient: 'from-blue-500 to-cyan-600',
      image: 'https://images.unsplash.com/photo-1740362381367-09cb98b4e1c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaGFybWFjZXV0aWNhbCUyMG1hbnVmYWN0dXJpbmclMjBlcXVpcG1lbnR8ZW58MXx8fHwxNzY4Njg2MTQ3fDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      icon: Beaker,
      name: t.industries.list.chemicals,
      description: t.industries.list.chemicalsDesc,
      gradient: 'from-purple-500 to-violet-600'
    },
    {
      icon: Beer,
      name: t.industries.list.beverages,
      description: t.industries.list.beveragesDesc,
      gradient: 'from-amber-500 to-orange-600'
    },
    {
      icon: PawPrint,
      name: t.industries.list.petcare,
      description: t.industries.list.petcareDesc,
      gradient: 'from-[#F46524] to-red-600'
    },
    {
      icon: Heart,
      name: t.industries.list.wellness,
      description: t.industries.list.wellnessDesc,
      gradient: 'from-red-500 to-pink-600'
    }
  ];

  return (
    <section id="industries" className="py-32 bg-[#0A2A4A] relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(30deg, transparent 45%, rgba(255,255,255,0.05) 45%, rgba(255,255,255,0.05) 55%, transparent 55%)',
          backgroundSize: '60px 60px'
        }}></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center max-w-4xl mx-auto mb-20"
        >
          <div className="inline-block bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-6 py-2 rounded-full font-semibold text-sm mb-6">
            {t.industries.badge}
          </div>
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-8 leading-tight">
            {t.industries.title}<br />
            <span className="bg-gradient-to-r from-[#F46524] to-orange-600 bg-clip-text text-transparent">
              {t.industries.titleAccent}
            </span>
          </h2>
          <p className="text-xl md:text-2xl text-gray-300 font-light">
            {t.industries.description}
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-20">
          {industries.map((industry, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              viewport={{ once: true }}
              className="group"
            >
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl p-8 hover:bg-white/10 transition-all duration-500 hover:-translate-y-2 text-center h-full flex flex-col items-center justify-center relative overflow-hidden">
                {/* Gradient Background on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${industry.gradient} opacity-0 group-hover:opacity-20 transition-opacity duration-500`}></div>
                
                <div className={`bg-gradient-to-br ${industry.gradient} w-20 h-20 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 shadow-2xl relative z-10`}>
                  <industry.icon className="text-white" size={36} />
                </div>
                <h3 className="text-xl font-bold text-white mb-2 relative z-10">{industry.name}</h3>
                <p className="text-sm text-gray-400 relative z-10">{industry.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Industry Showcase */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="grid md:grid-cols-3 gap-6"
        >
          {industries.slice(0, 3).map((industry, index) => industry.image && (
            <div key={index} className="rounded-3xl overflow-hidden shadow-2xl group relative">
              <img
                src={industry.image}
                alt={industry.name}
                className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A2A4A] via-[#0A2A4A]/50 to-transparent flex items-end p-8">
                <div className="text-white">
                  <div className={`bg-gradient-to-r ${industry.gradient} text-white px-4 py-1 rounded-full text-sm font-semibold inline-block mb-3`}>
                    {industry.name}
                  </div>
                  <h3 className="text-2xl font-bold">{industry.description}</h3>
                </div>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
