import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { ChevronLeft, ChevronRight, Settings, Zap, Shield } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { getFeaturedMachines } from '@/data/machines';

export function FeaturedMachines() {
  const { t, language } = useLanguage();
  const [currentSlide, setCurrentSlide] = useState(0);
  const machines = getFeaturedMachines();

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % machines.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + machines.length) % machines.length);
  };

  const currentMachine = machines[currentSlide];

  return (
    <section className="py-32 bg-gradient-to-b from-white via-gray-50 to-white relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-40 -right-20 w-96 h-96 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-40 -left-20 w-96 h-96 bg-gradient-to-br from-[#F46524]/10 to-orange-600/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center max-w-4xl mx-auto mb-20"
        >
          <div className="inline-block bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-6 py-2 rounded-full font-semibold text-sm mb-6">
            {t.featured.badge}
          </div>
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold text-[#0A2A4A] mb-8 leading-tight">
            {t.featured.title}<br />
            <span className="bg-gradient-to-r from-[#F46524] to-orange-600 bg-clip-text text-transparent">
              {t.featured.titleAccent}
            </span>
          </h2>
        </motion.div>

        <div className="relative max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-3xl overflow-hidden shadow-2xl border border-gray-100"
            >
              <div className="grid lg:grid-cols-2 gap-0">
                {/* Image */}
                <div className="relative h-96 lg:h-auto overflow-hidden">
                  <img
                    src={currentMachine.image}
                    alt={currentMachine.name[language]}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-[#0A2A4A]/90 to-[#0A2A4A]/40"></div>
                  
                  {/* Floating Badge */}
                  <div className="absolute top-8 left-8">
                    <div className="bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-6 py-3 rounded-2xl font-bold text-lg shadow-2xl">
                      {currentMachine.model}
                    </div>
                  </div>

                  {/* Features Badge */}
                  <div className="absolute bottom-8 left-8 right-8 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4">
                    <div className="grid grid-cols-3 gap-4 text-center text-white">
                      <div>
                        <Settings className="mx-auto mb-1" size={20} />
                        <p className="text-xs">{t.featured.custom}</p>
                      </div>
                      <div>
                        <Zap className="mx-auto mb-1" size={20} />
                        <p className="text-xs">{t.featured.fast}</p>
                      </div>
                      <div>
                        <Shield className="mx-auto mb-1" size={20} />
                        <p className="text-xs">{t.featured.durable}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-10 lg:p-12 flex flex-col justify-center">
                  <h3 className="text-4xl lg:text-5xl font-bold text-[#0A2A4A] mb-6 leading-tight">
                    {currentMachine.name[language]}
                  </h3>
                  <p className="text-lg text-[#6B6B6B] mb-8 leading-relaxed">
                    {currentMachine.description[language]}
                  </p>

                  {/* Specifications */}
                  <div className="space-y-4 mb-8">
                    {currentMachine.specs[language].map((spec, idx) => (
                      <div key={idx} className="flex items-start gap-3 bg-gray-50 rounded-2xl p-4">
                        <div className="bg-gradient-to-br from-[#F46524] to-orange-600 w-2 h-2 rounded-full mt-2 flex-shrink-0"></div>
                        <div className="flex-1">
                          <div className="font-bold text-[#0A2A4A]">{spec}</div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Industries */}
                  <div>
                    <p className="text-sm text-[#6B6B6B] mb-3 font-semibold uppercase tracking-wide">{t.featured.industries}</p>
                    <div className="flex flex-wrap gap-2">
                      {currentMachine.applications[language].map((industry, idx) => (
                        <span
                          key={idx}
                          className="bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-4 py-2 rounded-full text-sm font-medium"
                        >
                          {industry}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation Buttons */}
          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-white hover:bg-gray-50 text-[#0A2A4A] p-4 rounded-full shadow-2xl transition-all hover:scale-110 z-20 border border-gray-100"
          >
            <ChevronLeft size={24} />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-white hover:bg-gray-50 text-[#0A2A4A] p-4 rounded-full shadow-2xl transition-all hover:scale-110 z-20 border border-gray-100"
          >
            <ChevronRight size={24} />
          </button>

          {/* Slide Indicators */}
          <div className="flex justify-center gap-3 mt-10">
            {machines.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlide(idx)}
                className={`h-2 rounded-full transition-all ${
                  idx === currentSlide 
                    ? 'w-12 bg-gradient-to-r from-[#F46524] to-orange-600' 
                    : 'w-2 bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
