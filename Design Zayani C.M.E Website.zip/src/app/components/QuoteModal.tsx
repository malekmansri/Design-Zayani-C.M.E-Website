import { motion, AnimatePresence } from 'motion/react';
import { X, Send, CheckCircle } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Textarea } from '@/app/components/ui/textarea';
import { useLanguage } from '@/contexts/LanguageContext';
import { Machine } from '@/data/machines';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  machine: Machine | null;
}

export function QuoteModal({ isOpen, onClose, machine }: QuoteModalProps) {
  const { t, language } = useLanguage();
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    country: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
      setFormData({ name: '', company: '', email: '', phone: '', country: '', message: '' });
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-6 right-6 text-gray-400 hover:text-[#0A2A4A] p-2 rounded-full hover:bg-gray-100 transition-colors z-10"
          >
            <X size={24} />
          </button>

          {/* Content */}
          <div className="p-8 md:p-10">
            {!submitted ? (
              <>
                {/* Header */}
                <div className="mb-8">
                  <div className="inline-block bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-4 py-1 rounded-full text-sm font-semibold mb-4">
                    {t.quote.title}
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold text-[#0A2A4A] mb-3">
                    {t.quote.title}
                  </h2>
                  <p className="text-[#6B6B6B]">{t.quote.subtitle}</p>
                </div>

                {/* Machine Info */}
                {machine && (
                  <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-6 mb-8 border border-gray-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm text-[#6B6B6B] mb-1">{t.quote.machine}</div>
                        <div className="font-bold text-lg text-[#0A2A4A]">
                          {machine.model} - {machine.name[language]}
                        </div>
                      </div>
                      <div className="bg-gradient-to-r from-[#F46524] to-orange-600 text-white px-4 py-2 rounded-xl text-sm font-semibold">
                        {machine.model}
                      </div>
                    </div>
                  </div>
                )}

                {/* Form */}
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-[#0A2A4A] mb-2">
                        {t.quote.form.name} *
                      </label>
                      <Input
                        name="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full border-2 border-gray-200 focus:border-[#F46524] rounded-xl px-4 py-3"
                        placeholder={language === 'fr' ? 'Nom complet' : language === 'en' ? 'Full name' : 'الاسم الكامل'}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-[#0A2A4A] mb-2">
                        {t.quote.form.company}
                      </label>
                      <Input
                        name="company"
                        type="text"
                        value={formData.company}
                        onChange={handleChange}
                        className="w-full border-2 border-gray-200 focus:border-[#F46524] rounded-xl px-4 py-3"
                        placeholder={language === 'fr' ? 'Nom de société' : language === 'en' ? 'Company name' : 'اسم الشركة'}
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-[#0A2A4A] mb-2">
                        {t.quote.form.email} *
                      </label>
                      <Input
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full border-2 border-gray-200 focus:border-[#F46524] rounded-xl px-4 py-3"
                        placeholder="email@exemple.com"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-[#0A2A4A] mb-2">
                        {t.quote.form.phone}
                      </label>
                      <Input
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full border-2 border-gray-200 focus:border-[#F46524] rounded-xl px-4 py-3"
                        placeholder="+216 XX XXX XXX"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-[#0A2A4A] mb-2">
                      {t.quote.form.country}
                    </label>
                    <Input
                      name="country"
                      type="text"
                      value={formData.country}
                      onChange={handleChange}
                      className="w-full border-2 border-gray-200 focus:border-[#F46524] rounded-xl px-4 py-3"
                      placeholder={language === 'fr' ? 'Pays' : language === 'en' ? 'Country' : 'البلد'}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-[#0A2A4A] mb-2">
                      {t.quote.form.message}
                    </label>
                    <Textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={5}
                      className="w-full border-2 border-gray-200 focus:border-[#F46524] rounded-xl px-4 py-3 resize-none"
                      placeholder={language === 'fr' ? 'Détails de votre projet...' : language === 'en' ? 'Project details...' : 'تفاصيل المشروع...'}
                    />
                  </div>

                  <div className="flex gap-4">
                    <Button
                      type="button"
                      onClick={onClose}
                      variant="outline"
                      className="flex-1 border-2 border-gray-300 hover:bg-gray-50 rounded-xl py-6"
                    >
                      {t.quote.form.cancel}
                    </Button>
                    <Button
                      type="submit"
                      className="flex-1 bg-gradient-to-r from-[#F46524] to-orange-600 hover:from-[#d65620] hover:to-[#F46524] text-white rounded-xl py-6 group"
                    >
                      {t.quote.form.submit}
                      <Send className="ml-2 group-hover:translate-x-1 transition-transform" size={18} />
                    </Button>
                  </div>
                </form>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center py-16">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.5, type: 'spring' }}
                  className="bg-gradient-to-br from-green-500 to-emerald-600 w-24 h-24 rounded-full flex items-center justify-center mb-6 shadow-2xl"
                >
                  <CheckCircle className="text-white" size={48} />
                </motion.div>
                <h3 className="text-3xl font-bold text-[#0A2A4A] mb-3">{t.quote.success}</h3>
                <p className="text-lg text-[#6B6B6B] text-center max-w-md">
                  {t.quote.successMsg}
                </p>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
