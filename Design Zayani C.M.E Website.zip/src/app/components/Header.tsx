import { useState, useEffect } from 'react';
import { Menu, X, Globe } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { Language } from '@/i18n/translations';
import logo from 'figma:asset/76ee895d4f7ee403e9c31312bad2c49d4ece3069.png';

export function Header() {
  const { language, setLanguage, t } = useLanguage();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
      setIsMobileMenuOpen(false);
    }
  };

  const navLinks = [
    { name: t.nav.home, id: 'home' },
    { name: t.nav.about, id: 'about' },
    { name: t.nav.machines, id: 'products' },
    { name: t.nav.sectors, id: 'industries' },
    { name: t.nav.services, id: 'why-choose' },
    { name: t.nav.contact, id: 'contact' }
  ];

  const languages: { code: Language; label: string }[] = [
    { code: 'fr', label: 'FR' },
    { code: 'en', label: 'EN' },
    { code: 'ar', label: 'AR' }
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/90 backdrop-blur-xl shadow-lg' : 'bg-white/70 backdrop-blur-md'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex items-center">
              <img 
                src={logo} 
                alt="Zayani C.M.E" 
                className="h-12 w-auto"
              />
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className="text-[#0A2A4A] hover:text-[#F46524] transition-colors duration-200 font-medium px-4 py-2 rounded-lg hover:bg-gray-50"
              >
                {link.name}
              </button>
            ))}
          </nav>

          {/* Language Switcher & CTA */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Language Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowLangMenu(!showLangMenu)}
                className="flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <Globe size={18} className="text-[#6B6B6B]" />
                <span className="font-semibold text-[#0A2A4A]">{language.toUpperCase()}</span>
              </button>
              
              {showLangMenu && (
                <div className="absolute right-0 mt-2 bg-white rounded-xl shadow-2xl border border-gray-100 overflow-hidden min-w-[120px]">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code);
                        setShowLangMenu(false);
                      }}
                      className={`block w-full text-left px-4 py-3 hover:bg-gray-50 transition-colors ${
                        language === lang.code ? 'bg-[#F46524]/10 text-[#F46524] font-semibold' : 'text-[#0A2A4A]'
                      }`}
                    >
                      {lang.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <Button
              onClick={() => scrollToSection('contact')}
              className="bg-gradient-to-r from-[#F46524] to-[#ff7a3d] hover:from-[#d65620] hover:to-[#F46524] text-white rounded-full px-6 shadow-lg"
            >
              {language === 'fr' ? 'Devis' : language === 'en' ? 'Quote' : 'عرض'}
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden text-[#0A2A4A] p-2 hover:bg-gray-100 rounded-lg transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-2">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  className="text-left text-[#0A2A4A] hover:text-[#F46524] hover:bg-gray-50 transition-colors duration-200 font-medium py-3 px-4 rounded-lg"
                >
                  {link.name}
                </button>
              ))}
              
              {/* Mobile Language Switcher */}
              <div className="flex gap-2 px-4 py-2">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => setLanguage(lang.code)}
                    className={`flex-1 px-4 py-2 rounded-lg transition-colors ${
                      language === lang.code
                        ? 'bg-gradient-to-r from-[#F46524] to-[#ff7a3d] text-white'
                        : 'bg-gray-100 text-[#0A2A4A] hover:bg-gray-200'
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>

              <Button
                onClick={() => scrollToSection('contact')}
                className="bg-gradient-to-r from-[#F46524] to-[#ff7a3d] hover:from-[#d65620] hover:to-[#F46524] text-white w-full rounded-full"
              >
                {language === 'fr' ? 'Demander un Devis' : language === 'en' ? 'Request Quote' : 'طلب عرض'}
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}