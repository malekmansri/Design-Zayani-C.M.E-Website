import { LanguageProvider } from '@/contexts/LanguageContext';
import { Header } from '@/app/components/Header';
import { Hero } from '@/app/components/Hero';
import { About } from '@/app/components/About';
import { Products } from '@/app/components/Products';
import { FeaturedMachines } from '@/app/components/FeaturedMachines';
import { Industries } from '@/app/components/Industries';
import { WhyChoose } from '@/app/components/WhyChoose';
import { Contact } from '@/app/components/Contact';
import { Footer } from '@/app/components/Footer';

export default function App() {
  return (
    <LanguageProvider>
      <div className="min-h-screen bg-white">
        <Header />
        <main>
          <Hero />
          <About />
          <Products />
          <FeaturedMachines />
          <Industries />
          <WhyChoose />
          <Contact />
        </main>
        <Footer />
      </div>
    </LanguageProvider>
  );
}
