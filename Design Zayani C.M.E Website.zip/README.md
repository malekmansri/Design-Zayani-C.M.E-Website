
  # Design Zayani C.M.E Website

  This is a code bundle for Design Zayani C.M.E Website. The original project is available at https://www.figma.com/design/cy5Az0dSmtFY3iuES5cOOk/Design-Zayani-C.M.E-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  